# AX CHET — Phase 1 Supabase Android Integration

## Scope completed
- Added a single lazy Supabase client provider with Auth, PostgREST, Realtime, Storage, and Functions modules.
- Added a suspendable, read-only PostgREST root diagnostic using the configured publishable key.
- Kept the existing Compose screens, navigation, repository, package/application ID, signing configuration, and Android manifest permissions unchanged.
- Added configuration and HTTP-status classification unit tests.
- Added `.env` to the root `.gitignore`; `.env.example` documents the required configuration names.

## Versions selected
- Kotlin / serialization plugin: `2.2.10` (existing project version)
- Supabase Kotlin BOM: `3.2.2`
- Ktor Android engine: `3.2.2`
- Core library desugaring: `com.android.tools:desugar_jdk_libs:2.1.5`

Supabase 3.2.2 is from the 3.2.x line before the 3.2.3 release moved its Kotlin baseline to 2.2.20; the 3.2.2 changelog records Ktor 3.2.2. No Kotlin, AGP, Compose, or Gradle version was upgraded.

## Minimum SDK
`minSdk` remains 24. The SDK installation documentation allows Android versions below 26 when core-library desugaring is enabled. `isCoreLibraryDesugaringEnabled = true` and `desugar_jdk_libs:2.1.5` were added. This preserves support for Android 7.0/API 24 devices, subject to runtime verification on an API 24 device.

## Credential loading
The existing Secrets Gradle Plugin configuration reads root `.env` and falls back to `.env.example`. The local `.env` contains the supplied Supabase URL and publishable key; it is ignored by Git. `.env.example` contains the project URL and a placeholder key. Kotlin reads generated `BuildConfig.SUPABASE_URL` and `BuildConfig.SUPABASE_PUBLISHABLE_KEY`. No service-role/secret key is included.

## Verification status
- Version catalog TOML parsed successfully with Python's TOML parser.
- Existing manifest INTERNET permission confirmed.
- Root `.gitignore` ignores `.env`.
- Gradle build and unit tests: **not executed**. The supplied archive has no `gradlew` script or wrapper JAR, and this environment has no system Gradle installation (`gradle: command not found`).
- External PostgREST connectivity probe: **not completed**. DNS resolution failed in this environment (`curl: (6) Could not resolve host`), so no HTTP response was received. Run `SupabaseDiagnostics.run()` from the Android app on a connected device to obtain the real result.

## Files created
- `app/src/main/java/com/example/data/SupabaseProvider.kt`
- `app/src/main/java/com/example/data/SupabaseDiagnostics.kt`
- `app/src/test/java/com/example/data/SupabaseConfigurationTest.kt`
- `.env` (local ignored configuration)
- `PHASE1_REPORT.md`

## Files modified
- `gradle/libs.versions.toml`
- `build.gradle.kts`
- `app/build.gradle.kts`
- `.env.example`
- `.gitignore`
- `app/.gitignore`

## Diagnostic behavior
- Validates missing/placeholder URL and key and HTTPS URL format.
- Initializes the shared Supabase client before the HTTP probe.
- Requests only `GET /rest/v1/`; no profile or application table is queried.
- Distinguishes success, invalid credentials (401/403), server errors (5xx), other HTTP errors, timeout, network/DNS failures, and configuration errors.
- Does not log or return the publishable key.

## Next verification step
Open the project in Google AI Studio/Android Studio, confirm `.env` is available at the project root, run `:app:testDebugUnitTest` and `:app:assembleDebug`, then call `SupabaseDiagnostics.run()` on a device. Do not begin Phase 2 until those checks pass.
