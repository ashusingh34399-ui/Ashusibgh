# AX CHET — Phase 0 Source Audit

Audit date: 2026-11-07
Source archive: `AX_CHET_PHASE1_SUPABASE_ANDROID.zip`
Backend decision: keep the existing Supabase project.

## 1. Preservation baseline

The uploaded source is a native Android application using Kotlin and Jetpack Compose. Preserve the existing screens, components, theme, drawable assets, navigation structure, application ID, and Supabase project configuration while implementing the backend incrementally.

- Application ID: `com.aistudio.axchet.qqxpvt`
- Namespace: `com.example`
- `minSdk`: 24
- `targetSdk`: 36
- Android Gradle Plugin: 9.1.1
- Kotlin Gradle Plugin: 2.2.10
- Supabase Kotlin SDK: 3.2.2
- Ktor Android engine: 3.2.2

## 2. Findings

### Build and project setup

- The archive does not contain `gradlew`, `gradlew.bat`, `gradle-wrapper.jar`, or `gradle-wrapper.properties`.
- The project uses AGP 9.1.1. Its documented minimum Gradle version is 9.3.1; the Android Gradle Plugin release notes specify JDK 17.
- The build file configures a `debugConfig` signing key at the project root, but `debug.keystore` is absent from the archive and ignored by Git.
- The release signing configuration points to `my-upload-key.jks` by default; that file is absent and release passwords are environment variables.
- The README says to remove the debug signing assignment, while comments in `app/build.gradle.kts` say to retain it for AI Studio. Do not change signing until the actual build environment is identified and tested.
- Google Services Gradle plugin is applied with a warning strategy, but no `google-services.json` is present. Supabase itself does not require this file.
- The README still describes a `GEMINI_API_KEY` setup, while the current `.env` / `.env.example` configuration is Supabase-based. The README needs correction after build setup is confirmed.

### Supabase configuration

- `SupabaseProvider` validates the HTTPS project URL and publishable key, then lazily creates a Supabase client with Auth, PostgREST, Realtime, Storage, and Functions modules.
- The local `.env` contains both expected Supabase settings and is ignored by Git. The actual values must not be committed or printed in logs.
- Only a publishable client key is expected in the Android app. Never put a Supabase service-role/secret key in the APK.
- `SupabaseDiagnostics.run()` makes a read-only PostgREST root request, but no production screen or startup flow currently invokes it.
- Source search found no application repository calls to Supabase Auth, PostgREST, Realtime, Storage, or Functions beyond client initialization and the diagnostics probe.

### Application behavior

- `MainActivity.kt` starts on `Screen.Main`; the Auth screen is not the initial route.
- Email, phone, Google, and login UI actions currently call `onAuthSuccess()` without authenticating with Supabase.
- Sign-up only updates the local in-memory profile before entering the main screen.
- `AxChetRepository` is a process-local `MutableStateFlow` repository containing seeded demo users, chats, messages, stories, notifications, and scheduled messages.
- Sending a message updates local state and the AI conversation uses a keyword-based local reply generator. No remote AI request is made.
- Scheduled messages are local state; no server-side delivery worker is present.
- The UI is a useful visual baseline, but it must not be described as a production-connected chat app yet.

### Tests and verification

- Supabase configuration/status-classification unit tests exist.
- The ZIP passes archive integrity validation.
- A Gradle build and unit tests were not run: this environment has Java 21 but no system Gradle, and the archive has no Gradle wrapper.
- No real device connectivity test was performed. A configured URL/key is not proof of a successful live Supabase request.

## 3. Phase 0 implementation sequence

1. Keep the original ZIP unchanged as the rollback copy.
2. Open the extracted `axchet_phase1` directory as the project root; do not create a new Android app.
3. Restore the Gradle Wrapper using Gradle 9.3.1, matching AGP 9.1.1. Commit the wrapper scripts, wrapper JAR, and wrapper properties. Use JDK 17 or a supported newer JDK.
4. Resolve signing for the actual build target. For local debug builds, use a generated local debug keystore or the build environment's documented signing mechanism. Keep release signing secrets outside source control. Do not delete AI Studio signing configuration without confirming how that environment expects it.
5. Confirm the SDK platform/build-tools needed by `compileSdk 36.1` are installed in the build environment. Do not change `compileSdk`, `targetSdk`, `minSdk`, Kotlin, AGP, Compose, or Supabase versions merely to silence an unverified error.
6. Decide whether Firebase is intentionally used. If not, remove only unused Google Services/Firebase setup in a separately reviewed change; if yes, add the correct project configuration securely. Do not add a random `google-services.json`.
7. Run `./gradlew --version`, `./gradlew :app:testDebugUnitTest`, and `./gradlew :app:assembleDebug`.
8. Install the debug APK on a real Android device and record launch, navigation, and crash results.
9. Invoke `SupabaseDiagnostics.run()` from a temporary developer-only diagnostic action and verify the live HTTP result on a connected device. Do not log the key.
10. Only after build, tests, launch, and Supabase connectivity pass, begin Phase 1 implementation: auth/session wiring, then remote profile persistence. Keep demo data clearly isolated from production data.

## 4. Phase 0 exit criteria

- Wrapper is present and reproducible.
- Debug build and existing unit tests pass.
- App launches on a real device without changing the existing UI.
- Supabase diagnostics reports a real successful response from the existing project.
- Signing and configuration files are handled without committing secrets.
- The project has a verified backup and a documented baseline.

## 5. Changes made by this audit

Only this `PHASE0_AUDIT.md` report was added. No Kotlin, Gradle, manifest, resource, UI, Supabase, or application behavior files were modified.
