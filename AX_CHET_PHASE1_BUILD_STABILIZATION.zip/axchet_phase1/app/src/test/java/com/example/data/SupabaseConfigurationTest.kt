package com.example.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SupabaseConfigurationTest {
    private val validUrl = "https://example.supabase.co"
    private val validKey = "sb_publishable_test_key"

    @Test fun missingUrlIsRejected() {
        val result = SupabaseProvider.loadConfiguration("", validKey)
        assertTrue(result is SupabaseProvider.ConfigurationResult.Invalid)
        assertTrue((result as SupabaseProvider.ConfigurationResult.Invalid).reason.contains("URL"))
    }

    @Test fun missingPublishableKeyIsRejected() {
        val result = SupabaseProvider.loadConfiguration(validUrl, "")
        assertTrue(result is SupabaseProvider.ConfigurationResult.Invalid)
        assertTrue((result as SupabaseProvider.ConfigurationResult.Invalid).reason.contains("key"))
    }

    @Test fun placeholderPublishableKeyIsRejected() {
        val result = SupabaseProvider.loadConfiguration(validUrl, "YOUR_SUPABASE_PUBLISHABLE_KEY")
        assertTrue(result is SupabaseProvider.ConfigurationResult.Invalid)
    }

    @Test fun invalidHttpUrlIsRejected() {
        val result = SupabaseProvider.loadConfiguration("http://example.supabase.co", validKey)
        assertTrue(result is SupabaseProvider.ConfigurationResult.Invalid)
    }

    @Test fun diagnosticClassifiesSuccessfulResponse() {
        assertTrue(SupabaseDiagnostics.classifyHttpStatus(200) is SupabaseDiagnostics.Result.Success)
    }

    @Test fun diagnosticClassifiesInvalidCredentialsSeparately() {
        assertTrue(SupabaseDiagnostics.classifyHttpStatus(401) is SupabaseDiagnostics.Result.InvalidCredentials)
        assertTrue(SupabaseDiagnostics.classifyHttpStatus(403) is SupabaseDiagnostics.Result.InvalidCredentials)
    }

    @Test fun diagnosticClassifiesServerAndOtherHttpErrors() {
        assertTrue(SupabaseDiagnostics.classifyHttpStatus(503) is SupabaseDiagnostics.Result.ServerError)
        assertTrue(SupabaseDiagnostics.classifyHttpStatus(404) is SupabaseDiagnostics.Result.HttpError)
    }

    @Test fun validConfigurationLoadsAndNormalizesTrailingSlash() {
        val result = SupabaseProvider.loadConfiguration("$validUrl/", validKey)
        assertTrue(result is SupabaseProvider.ConfigurationResult.Valid)
        assertEquals(validUrl, (result as SupabaseProvider.ConfigurationResult.Valid).configuration.url)
        assertEquals(validKey, result.configuration.publishableKey)
    }
}
