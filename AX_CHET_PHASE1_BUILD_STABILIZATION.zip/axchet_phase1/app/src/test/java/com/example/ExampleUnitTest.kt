package com.example

import com.example.data.AxChetRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testCurrentUserAdminAndBadges() {
    val user = AxChetRepository.currentUser.value
    assertEquals("Ashu", user.name)
    assertEquals("@ax_ashu", user.username)
    assertTrue("Admin should have gold admin badge", user.isGoldAdmin)
    assertTrue("Admin should have blue verified badge", user.isBlueVerified)
  }

  @Test
  fun testMessagingAndReactions() {
    val convs = AxChetRepository.conversations.value
    assertTrue("Conversations list should contain Ashu", convs.any { it.title.contains("Ashu") })
    assertTrue("Conversations list should contain AI Assistant", convs.any { it.isAiAssistant })

    // Send a message
    AxChetRepository.sendMessage("conv_ashu", "Testing realtime flow")
    val messages = AxChetRepository.getMessagesForConversation("conv_ashu").value
    val lastMsg = messages.last()
    assertEquals("Testing realtime flow", lastMsg.text)
    assertTrue(lastMsg.isOutgoing)

    // Add reaction
    AxChetRepository.addReaction("conv_ashu", lastMsg.id, "🔥")
    val updatedMessages = AxChetRepository.getMessagesForConversation("conv_ashu").value
    val reactedMsg = updatedMessages.find { it.id == lastMsg.id }
    assertTrue(reactedMsg!!.reactions.contains("🔥"))
  }

  @Test
  fun testScheduledMessages() {
    AxChetRepository.scheduleMessage("Gamer Priya", "Stream starts soon!", "Today", "07:00 PM")
    val scheduled = AxChetRepository.scheduledMessages.value
    assertTrue(scheduled.any { it.recipientName == "Gamer Priya" && it.text == "Stream starts soon!" })
  }

  @Test
  fun testUsernameSearch() {
    val results = AxChetRepository.searchUsers("@tech_aryan")
    assertEquals(1, results.size)
    assertEquals("Tech Aryan", results.first().name)
    assertTrue(results.first().isBlueVerified)
  }
}
