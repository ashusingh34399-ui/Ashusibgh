package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.AxChetRepository
import com.example.model.Conversation
import com.example.model.Story
import com.example.ui.components.AddStoryItemView
import com.example.ui.components.AxChetTopBar
import com.example.ui.components.BlueVerifiedBadge
import com.example.ui.components.GoldAdminBadge
import com.example.ui.components.StoryItemView
import com.example.ui.components.StoryViewerDialog
import com.example.ui.components.UserAvatar
import com.example.ui.theme.AxBorderGlow
import com.example.ui.theme.AxBorderSubtle
import com.example.ui.theme.AxBrightViolet
import com.example.ui.theme.AxDeepBlack
import com.example.ui.theme.AxNeonViolet
import com.example.ui.theme.AxSoftPurple
import com.example.ui.theme.AxTextDim
import com.example.ui.theme.AxTextMuted
import com.example.ui.theme.AxWhite
import kotlinx.coroutines.launch

enum class ChatFilterTab {
    CHATS,
    GROUPS,
    AI
}

@Composable
fun MainChatsScreen(
    onConversationClick: (String) -> Unit,
    onSearchClick: () -> Unit,
    onNotificationsClick: () -> Unit,
    onVerificationClick: () -> Unit,
    onScheduledClick: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val conversations by AxChetRepository.conversations.collectAsState()
    val stories by AxChetRepository.stories.collectAsState()
    val currentUser by AxChetRepository.currentUser.collectAsState()
    val notifications by AxChetRepository.notifications.collectAsState()
    val unreadNotifsCount = notifications.count { it.isUnread }

    var selectedFilter by remember { mutableStateOf(ChatFilterTab.CHATS) }
    var viewingStory by remember { mutableStateOf<Story?>(null) }
    var showAddStoryDialog by remember { mutableStateOf(false) }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Color(0xFF100B1C),
                drawerContentColor = AxWhite,
                modifier = Modifier
                    .width(300.dp)
                    .border(
                        1.dp,
                        Brush.horizontalGradient(listOf(Color.Transparent, AxBorderGlow)),
                        RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
                    )
            ) {
                // Drawer Profile Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color(0xFF28114C),
                                    Color(0xFF130924)
                                )
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        UserAvatar(
                            name = currentUser.name,
                            avatarRes = currentUser.avatarRes,
                            size = 56.dp,
                            isGoldAdmin = currentUser.isGoldAdmin,
                            isBlueVerified = currentUser.isBlueVerified,
                            ringGlow = true
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = currentUser.name,
                                color = AxWhite,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (currentUser.isGoldAdmin) {
                                Spacer(modifier = Modifier.width(6.dp))
                                GoldAdminBadge(size = 18.dp)
                            }
                        }
                        Text(
                            text = currentUser.username,
                            color = AxSoftPurple,
                            fontSize = 13.sp
                        )
                        Text(
                            text = currentUser.bio,
                            color = AxTextMuted,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }

                HorizontalDivider(color = AxBorderSubtle)

                Spacer(modifier = Modifier.height(12.dp))

                DrawerMenuItem(
                    icon = Icons.Default.Bookmark,
                    title = "Saved Messages",
                    onClick = {
                        scope.launch { drawerState.close() }
                        onConversationClick("ai_assistant")
                    }
                )

                DrawerMenuItem(
                    icon = Icons.Default.CalendarMonth,
                    title = "Scheduled Messages",
                    onClick = {
                        scope.launch { drawerState.close() }
                        onScheduledClick()
                    }
                )

                DrawerMenuItem(
                    icon = Icons.Default.Verified,
                    title = "Verification Status",
                    onClick = {
                        scope.launch { drawerState.close() }
                        onVerificationClick()
                    }
                )

                DrawerMenuItem(
                    icon = Icons.Default.DarkMode,
                    title = "Cyber Dark Theme",
                    subtitle = "Neon Violet Glow (Active)",
                    onClick = { scope.launch { drawerState.close() } }
                )

                Spacer(modifier = Modifier.weight(1f))

                HorizontalDivider(color = AxBorderSubtle)

                DrawerMenuItem(
                    icon = Icons.Default.Logout,
                    title = "Logout",
                    iconTint = Color(0xFFF87171),
                    onClick = {
                        scope.launch { drawerState.close() }
                        onLogout()
                    }
                )

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    ) {
        Column(
            modifier = modifier
                .fillMaxSize()
                .background(AxDeepBlack)
        ) {
            // Ax Chet Top Bar matching Screenshot 2
            AxChetTopBar(
                onMenuClick = { scope.launch { drawerState.open() } },
                onSearchClick = onSearchClick,
                onNotificationClick = onNotificationsClick,
                unreadNotificationsCount = unreadNotifsCount
            )

            // Filter Tabs: [Chats] [Groups] [AI]
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                FilterTabPill(
                    title = "Chats",
                    icon = Icons.Default.Chat,
                    isSelected = selectedFilter == ChatFilterTab.CHATS,
                    testTag = "tab_filter_chats",
                    onClick = { selectedFilter = ChatFilterTab.CHATS }
                )
                FilterTabPill(
                    title = "Groups",
                    icon = Icons.Default.Group,
                    isSelected = selectedFilter == ChatFilterTab.GROUPS,
                    testTag = "tab_filter_groups",
                    onClick = { selectedFilter = ChatFilterTab.GROUPS }
                )
                FilterTabPill(
                    title = "AI",
                    icon = Icons.Default.SmartToy,
                    isSelected = selectedFilter == ChatFilterTab.AI,
                    testTag = "tab_filter_ai",
                    onClick = { selectedFilter = ChatFilterTab.AI }
                )
            }

            // Horizontal Stories Bar
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Add Story item
                item {
                    AddStoryItemView(
                        onClick = { showAddStoryDialog = true }
                    )
                }

                // Story list
                items(stories) { story ->
                    StoryItemView(
                        story = story,
                        onClick = { viewingStory = story }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Filtered Conversations List
            val filteredConversations = remember(selectedFilter, conversations) {
                when (selectedFilter) {
                    ChatFilterTab.CHATS -> conversations.filter { !it.isGroup && !it.isChannel }
                    ChatFilterTab.GROUPS -> conversations.filter { it.isGroup || it.isChannel }
                    ChatFilterTab.AI -> conversations.filter { it.isAiAssistant }
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(filteredConversations, key = { it.id }) { conv ->
                    ConversationItemCard(
                        conversation = conv,
                        onClick = { onConversationClick(conv.id) }
                    )
                }
            }
        }
    }

    // Story Viewer Dialog
    viewingStory?.let { story ->
        StoryViewerDialog(
            story = story,
            onDismiss = { viewingStory = null },
            onSendReply = { reply ->
                AxChetRepository.sendMessage(
                    conversationId = if (story.userName.contains("Ashu")) "conv_ashu" else "conv_priya",
                    text = "Replied to story: $reply"
                )
            }
        )
    }

    // Add Story Dialog
    if (showAddStoryDialog) {
        Dialog(onDismissRequest = { showAddStoryDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF160E2A),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AxBorderGlow, RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                var newStoryText by remember { mutableStateOf("") }
                Column {
                    Text(
                        text = "Share Story to Ax Chet",
                        color = AxWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = newStoryText,
                        onValueChange = { newStoryText = it },
                        placeholder = { Text("What's on your mind? ✨", color = AxTextMuted) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF100A1F),
                            unfocusedContainerColor = Color(0xFF100A1F),
                            focusedTextColor = AxWhite,
                            unfocusedTextColor = AxWhite
                        )
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            showAddStoryDialog = false
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = AxBrightViolet)
                    ) {
                        Text("Post Story", color = AxWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun FilterTabPill(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    testTag: String,
    onClick: () -> Unit
) {
    val backgroundBrush = if (isSelected) {
        Brush.horizontalGradient(
            listOf(
                Color(0xFF8B2CF5),
                Color(0xFF5B1AA3)
            )
        )
    } else {
        Brush.horizontalGradient(
            listOf(
                Color(0xFF140D24),
                Color(0xFF140D24)
            )
        )
    }

    val borderColor = if (isSelected) AxBrightViolet else Color(0xFF261942)

    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(backgroundBrush)
            .border(1.dp, borderColor, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 7.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = if (isSelected) AxWhite else AxTextMuted,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = title,
            color = if (isSelected) AxWhite else AxTextMuted,
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

@Composable
fun ConversationItemCard(
    conversation: Conversation,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 10.dp)
            .testTag("chat_item_${conversation.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Avatar with badges
        UserAvatar(
            name = conversation.title,
            avatarRes = conversation.avatarRes,
            size = 52.dp,
            isGoldAdmin = conversation.isGoldAdmin,
            isBlueVerified = conversation.isBlueVerified,
            isOnline = conversation.isOnline,
            isGroup = conversation.isGroup,
            isAiAssistant = conversation.isAiAssistant
        )

        Spacer(modifier = Modifier.width(14.dp))

        // Center: Title, Badges, and Last Message
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = conversation.title,
                    color = AxWhite,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )

                if (conversation.isGoldAdmin) {
                    Spacer(modifier = Modifier.width(6.dp))
                    GoldAdminBadge(size = 16.dp)
                } else if (conversation.isBlueVerified) {
                    Spacer(modifier = Modifier.width(6.dp))
                    BlueVerifiedBadge(size = 15.dp)
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = conversation.lastMessage,
                color = if (conversation.unreadCount > 0) AxBrightViolet else AxTextMuted,
                fontSize = 13.sp,
                fontWeight = if (conversation.unreadCount > 0) FontWeight.Medium else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Right side: Timestamp & Unread Badge or Pin
        Column(
            horizontalAlignment = Alignment.End
        ) {
            Text(
                text = conversation.lastMessageTime,
                color = if (conversation.unreadCount > 0) AxBrightViolet else AxTextDim,
                fontSize = 12.sp,
                fontWeight = if (conversation.unreadCount > 0) FontWeight.Bold else FontWeight.Normal
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (conversation.isPinned) {
                Icon(
                    imageVector = Icons.Default.PushPin,
                    contentDescription = "Pinned",
                    tint = AxTextMuted,
                    modifier = Modifier.size(16.dp)
                )
            } else if (conversation.unreadCount > 0) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(AxNeonViolet),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${conversation.unreadCount}",
                        color = AxWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun DrawerMenuItem(
    icon: ImageVector,
    title: String,
    subtitle: String? = null,
    iconTint: Color = AxBrightViolet,
    onClick: () -> Unit
) {
    NavigationDrawerItem(
        icon = {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(22.dp)
            )
        },
        label = {
            Column {
                Text(
                    text = title,
                    color = AxWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
                if (subtitle != null) {
                    Text(
                        text = subtitle,
                        color = AxTextDim,
                        fontSize = 11.sp
                    )
                }
            }
        },
        selected = false,
        onClick = onClick,
        colors = NavigationDrawerItemDefaults.colors(
            unselectedContainerColor = Color.Transparent
        ),
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
    )
}
