package com.example.model

enum class MessageType {
    TEXT,
    IMAGE,
    FILE,
    VOICE,
    LOCATION,
    SYSTEM
}

enum class VerificationStatus {
    PENDING,
    APPROVED,
    REJECTED
}

data class User(
    val id: String,
    val name: String,
    val username: String,
    val avatarRes: Int? = null,
    val isOnline: Boolean = false,
    val lastSeenText: String = "Offline",
    val isBlueVerified: Boolean = false,
    val isGoldAdmin: Boolean = false,
    val roleTitle: String? = null,
    val bio: String = "",
    val postsCount: String = "0",
    val followersCount: String = "0",
    val followingCount: String = "0",
    val email: String = "",
    val phone: String = ""
)

data class Message(
    val id: String,
    val conversationId: String,
    val senderId: String,
    val senderName: String,
    val senderAvatarRes: Int? = null,
    val text: String,
    val type: MessageType = MessageType.TEXT,
    val fileName: String? = null,
    val fileSize: String? = null,
    val audioDurationSeconds: Int = 0,
    val timestamp: String,
    val isOutgoing: Boolean,
    val isDelivered: Boolean = true,
    val isRead: Boolean = true,
    val reactions: List<String> = emptyList(),
    val isPinned: Boolean = false
)

data class Conversation(
    val id: String,
    val title: String,
    val username: String = "",
    val avatarRes: Int? = null,
    val isGroup: Boolean = false,
    val isChannel: Boolean = false,
    val isAiAssistant: Boolean = false,
    val lastMessage: String,
    val lastMessageTime: String,
    val unreadCount: Int = 0,
    val isPinned: Boolean = false,
    val isOnline: Boolean = false,
    val isBlueVerified: Boolean = false,
    val isGoldAdmin: Boolean = false,
    val isMuted: Boolean = false,
    val membersCount: Int = 1
)

data class Story(
    val id: String,
    val userId: String,
    val userName: String,
    val userAvatarRes: Int? = null,
    val isGoldAdmin: Boolean = false,
    val isBlueVerified: Boolean = false,
    val isOnline: Boolean = false,
    val storyText: String = "",
    val timeAgo: String = "Just now",
    val isViewed: Boolean = false
)

data class ScheduledMessage(
    val id: String,
    val conversationId: String,
    val recipientName: String,
    val recipientAvatarRes: Int? = null,
    val text: String,
    val scheduledDateStr: String,
    val scheduledTimeStr: String,
    val isSent: Boolean = false,
    val isCancelled: Boolean = false
)

data class VerificationRequest(
    val id: String,
    val fullName: String,
    val category: String,
    val documentProof: String,
    val status: VerificationStatus,
    val submissionDate: String
)

data class NotificationItem(
    val id: String,
    val title: String,
    val message: String,
    val time: String,
    val isUnread: Boolean = true,
    val isGoldAdmin: Boolean = false
)
