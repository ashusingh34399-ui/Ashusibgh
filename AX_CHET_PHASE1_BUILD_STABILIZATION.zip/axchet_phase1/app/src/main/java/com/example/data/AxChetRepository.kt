package com.example.data

import com.example.R
import com.example.model.Conversation
import com.example.model.Message
import com.example.model.MessageType
import com.example.model.NotificationItem
import com.example.model.ScheduledMessage
import com.example.model.Story
import com.example.model.User
import com.example.model.VerificationRequest
import com.example.model.VerificationStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

object AxChetRepository {

    // Current User Profile
    private val _currentUser = MutableStateFlow(
        User(
            id = "user_ashu_admin",
            name = "Ashu",
            username = "@ax_ashu",
            avatarRes = R.drawable.avatar_ashu,
            isOnline = true,
            lastSeenText = "Online",
            isBlueVerified = true,
            isGoldAdmin = true,
            roleTitle = "Ax Chet Admin",
            bio = "Official Admin of Ax Chet 💜",
            postsCount = "124",
            followersCount = "56.8K",
            followingCount = "12",
            email = "ashusinghrwa@gmail.com",
            phone = "+91 98765 43210"
        )
    )
    val currentUser: StateFlow<User> = _currentUser.asStateFlow()

    // Searchable Users directory
    val allUsers = listOf(
        User(
            id = "user_ashu_admin",
            name = "Ashu (Admin)",
            username = "@ax_ashu",
            avatarRes = R.drawable.avatar_ashu,
            isOnline = true,
            isBlueVerified = true,
            isGoldAdmin = true,
            roleTitle = "Ax Chet Admin",
            bio = "Official Admin of Ax Chet 💜"
        ),
        User(
            id = "user_aryan",
            name = "Tech Aryan",
            username = "@tech_aryan",
            avatarRes = R.drawable.avatar_aryan,
            isOnline = true,
            isBlueVerified = true,
            isGoldAdmin = false,
            bio = "Android Engineer & Tech Reviewer 💻"
        ),
        User(
            id = "user_priya",
            name = "Gamer Priya",
            username = "@gamer_priya",
            avatarRes = R.drawable.avatar_priya,
            isOnline = true,
            isBlueVerified = true,
            isGoldAdmin = false,
            bio = "Pro Gamer & Digital Creator 🎮✨"
        ),
        User(
            id = "user_arun",
            name = "Arun Sharma",
            username = "@arun_dev",
            avatarRes = null,
            isOnline = true,
            isBlueVerified = false,
            isGoldAdmin = false,
            bio = "Building scalable cloud systems"
        ),
        User(
            id = "channel_updates",
            name = "Ax Updates",
            username = "@ax_updates",
            avatarRes = null,
            isOnline = false,
            isBlueVerified = false,
            isGoldAdmin = true,
            bio = "Official news, changelogs and announcements for Ax Chet"
        ),
        User(
            id = "user_kavita",
            name = "Kavita Rao",
            username = "@kavita_r",
            avatarRes = null,
            isOnline = false,
            isBlueVerified = false,
            isGoldAdmin = false,
            bio = "UI/UX Designer & Motion Artist"
        )
    )

    // Conversations List (Matching the Screenshot 2)
    private val _conversations = MutableStateFlow(
        listOf(
            Conversation(
                id = "ai_assistant",
                title = "AI Assistant",
                username = "@ax_ai",
                isAiAssistant = true,
                lastMessage = "Ask me anything...",
                lastMessageTime = "10:20 AM",
                isPinned = true,
                isBlueVerified = true,
                unreadCount = 0
            ),
            Conversation(
                id = "conv_ashu",
                title = "Ashu (Admin)",
                username = "@ax_ashu",
                avatarRes = R.drawable.avatar_ashu,
                lastMessage = "App update & new features...",
                lastMessageTime = "10:15 AM",
                isOnline = true,
                isGoldAdmin = true,
                isPinned = true,
                unreadCount = 0
            ),
            Conversation(
                id = "conv_aryan",
                title = "Tech Aryan",
                username = "@tech_aryan",
                avatarRes = R.drawable.avatar_aryan,
                lastMessage = "Thanks bro! 👍",
                lastMessageTime = "09:58 AM",
                isOnline = true,
                isBlueVerified = true,
                unreadCount = 2
            ),
            Conversation(
                id = "conv_priya",
                title = "Gamer Priya",
                username = "@gamer_priya",
                avatarRes = R.drawable.avatar_priya,
                lastMessage = "New video coming soon 🔥",
                lastMessageTime = "08:40 AM",
                isOnline = true,
                isBlueVerified = true,
                unreadCount = 1
            ),
            Conversation(
                id = "conv_ax_updates",
                title = "Ax Updates",
                username = "@ax_updates",
                avatarRes = null,
                isChannel = true,
                lastMessage = "Ax Chet v3.0 is now live! 🎉",
                lastMessageTime = "Yesterday",
                isGoldAdmin = true,
                membersCount = 142500
            ),
            Conversation(
                id = "conv_study_group",
                title = "Study Group",
                username = "@study_group",
                avatarRes = null,
                isGroup = true,
                lastMessage = "Notes uploaded ✅",
                lastMessageTime = "Yesterday",
                membersCount = 38
            )
        )
    )
    val conversations: StateFlow<List<Conversation>> = _conversations.asStateFlow()

    // Stories (Matches Stories row in Screenshot 2)
    private val _stories = MutableStateFlow(
        listOf(
            Story(
                id = "story_1",
                userId = "user_ashu_admin",
                userName = "Ashu",
                userAvatarRes = R.drawable.avatar_ashu,
                isGoldAdmin = true,
                isOnline = true,
                storyText = "Ax Chet v3.0 build deployed! Testing dark purple glowing glassmorphism on Android 🚀✨",
                timeAgo = "10m ago"
            ),
            Story(
                id = "story_2",
                userId = "user_priya",
                userName = "Priya",
                userAvatarRes = R.drawable.avatar_priya,
                isBlueVerified = true,
                isOnline = true,
                storyText = "Starting live gameplay stream tonight at 8 PM! Don't miss it 🎮🔥",
                timeAgo = "45m ago"
            ),
            Story(
                id = "story_3",
                userId = "user_arun",
                userName = "Arun",
                userAvatarRes = null,
                isOnline = true,
                storyText = "Weekend hackathon coding mode ☕💻",
                timeAgo = "2h ago"
            ),
            Story(
                id = "story_4",
                userId = "user_aryan",
                userName = "Aryan",
                userAvatarRes = R.drawable.avatar_aryan,
                isBlueVerified = true,
                isOnline = true,
                storyText = "Deep dive into Kotlin coroutines & Supabase realtime channels ⚡",
                timeAgo = "4h ago"
            )
        )
    )
    val stories: StateFlow<List<Story>> = _stories.asStateFlow()

    // Messages per conversation (Prefilled for Ashu matching Screenshot 3)
    private val messagesMap = mutableMapOf<String, MutableStateFlow<List<Message>>>()

    init {
        // Conversation with Ashu (matches Screenshot 3)
        val ashuMessages = listOf(
            Message(
                id = "m1",
                conversationId = "conv_ashu",
                senderId = "user_ashu_admin",
                senderName = "Ashu (Admin)",
                senderAvatarRes = R.drawable.avatar_ashu,
                text = "Hi भाई! 👋",
                timestamp = "10:10 AM",
                isOutgoing = false
            ),
            Message(
                id = "m2",
                conversationId = "conv_ashu",
                senderId = "current_user",
                senderName = "Me",
                text = "Hello bro! 👋",
                timestamp = "10:11 AM",
                isOutgoing = true,
                reactions = listOf("👋")
            ),
            Message(
                id = "m3",
                conversationId = "conv_ashu",
                senderId = "user_ashu_admin",
                senderName = "Ashu (Admin)",
                senderAvatarRes = R.drawable.avatar_ashu,
                text = "Ax Chet v3.0 ka update ready hai, testing karlo. 🚀",
                timestamp = "10:12 AM",
                isOutgoing = false
            ),
            Message(
                id = "m4",
                conversationId = "conv_ashu",
                senderId = "current_user",
                senderName = "Me",
                text = "",
                type = MessageType.FILE,
                fileName = "AxChet_v3.0.apk",
                fileSize = "52.4 MB • APK",
                timestamp = "10:13 AM",
                isOutgoing = true
            ),
            Message(
                id = "m5",
                conversationId = "conv_ashu",
                senderId = "user_ashu_admin",
                senderName = "Ashu (Admin)",
                senderAvatarRes = R.drawable.avatar_ashu,
                text = "Awesome! 🔥 Aaj hi test karta hoon.",
                timestamp = "10:14 AM",
                isOutgoing = false,
                reactions = listOf("🔥")
            ),
            Message(
                id = "m6",
                conversationId = "conv_ashu",
                senderId = "current_user",
                senderName = "Me",
                text = "Ok bro 👍",
                timestamp = "10:15 AM",
                isOutgoing = true,
                reactions = listOf("👍")
            )
        )
        messagesMap["conv_ashu"] = MutableStateFlow(ashuMessages)

        // AI Assistant Conversation
        val aiMessages = listOf(
            Message(
                id = "ai_m1",
                conversationId = "ai_assistant",
                senderId = "ai_bot",
                senderName = "Ax AI Assistant",
                text = "Hello! I am your Ax Chet intelligent assistant. I can help write messages, generate code, summarize chats, schedule events, and translate text. How can I help you today?",
                timestamp = "10:20 AM",
                isOutgoing = false
            )
        )
        messagesMap["ai_assistant"] = MutableStateFlow(aiMessages)

        // Tech Aryan
        val aryanMessages = listOf(
            Message(
                id = "ar_m1",
                conversationId = "conv_aryan",
                senderId = "current_user",
                senderName = "Me",
                text = "Hey Aryan, did you check the new neon UI layout?",
                timestamp = "09:55 AM",
                isOutgoing = true
            ),
            Message(
                id = "ar_m2",
                conversationId = "conv_aryan",
                senderId = "user_aryan",
                senderName = "Tech Aryan",
                senderAvatarRes = R.drawable.avatar_aryan,
                text = "Yes! The glowing borders and glassmorphism look super clean.",
                timestamp = "09:57 AM",
                isOutgoing = false
            ),
            Message(
                id = "ar_m3",
                conversationId = "conv_aryan",
                senderId = "user_aryan",
                senderName = "Tech Aryan",
                senderAvatarRes = R.drawable.avatar_aryan,
                text = "Thanks bro! 👍",
                timestamp = "09:58 AM",
                isOutgoing = false
            )
        )
        messagesMap["conv_aryan"] = MutableStateFlow(aryanMessages)
    }

    fun getMessagesForConversation(convId: String): StateFlow<List<Message>> {
        if (!messagesMap.containsKey(convId)) {
            messagesMap[convId] = MutableStateFlow(emptyList())
        }
        return messagesMap[convId]!!.asStateFlow()
    }

    fun sendMessage(
        conversationId: String,
        text: String,
        type: MessageType = MessageType.TEXT,
        fileName: String? = null,
        fileSize: String? = null,
        audioDuration: Int = 0
    ) {
        val flow = messagesMap.getOrPut(conversationId) { MutableStateFlow(emptyList()) }
        val timeNow = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val newMessage = Message(
            id = UUID.randomUUID().toString(),
            conversationId = conversationId,
            senderId = "current_user",
            senderName = "Me",
            text = text,
            type = type,
            fileName = fileName,
            fileSize = fileSize,
            audioDurationSeconds = audioDuration,
            timestamp = timeNow,
            isOutgoing = true,
            isDelivered = true,
            isRead = false
        )
        flow.value = flow.value + newMessage

        // Update conversation preview
        val preview = when (type) {
            MessageType.FILE -> "📎 $fileName"
            MessageType.VOICE -> "🎤 Voice message (${audioDuration}s)"
            MessageType.IMAGE -> "📷 Photo"
            MessageType.LOCATION -> "📍 Location shared"
            else -> text
        }
        _conversations.value = _conversations.value.map { conv ->
            if (conv.id == conversationId) {
                conv.copy(lastMessage = preview, lastMessageTime = timeNow)
            } else conv
        }

        // Auto-reply for AI Assistant
        if (conversationId == "ai_assistant") {
            generateAiReply(text)
        }
    }

    private fun generateAiReply(userPrompt: String) {
        val aiFlow = messagesMap["ai_assistant"] ?: return
        val timeNow = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
        val response = when {
            userPrompt.contains("code", ignoreCase = true) || userPrompt.contains("kotlin", ignoreCase = true) ->
                "Here is how you can use Kotlin Flow in Ax Chet:\n```kotlin\nval messages = repository.getMessagesFlow()\n    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())\n```\nLet me know if you need edge function or Supabase RPC examples!"

            userPrompt.contains("translate", ignoreCase = true) ->
                "Translation:\n'नमस्ते! Ax Chet में आपका स्वागत है। (Hello! Welcome to Ax Chet.)'\nPowered by Ax Chet AI Engine."

            userPrompt.contains("schedule", ignoreCase = true) ->
                "You can schedule messages directly from any chat using the 📅 Schedule button in the attachment drawer or via the Schedule tab in the bottom bar."

            userPrompt.contains("admin", ignoreCase = true) || userPrompt.contains("gold", ignoreCase = true) ->
                "The Gold [A] Shield badge is reserved exclusively for authorized backend administrators like Ashu. Regular users cannot assign it. For verified status, you can submit a Blue verification request!"

            else ->
                "I understand! Ax Chet provides real-time messaging, group channels, scheduled delivery, and high-performance offline persistence. What would you like to do next?"
        }

        val aiMsg = Message(
            id = UUID.randomUUID().toString(),
            conversationId = "ai_assistant",
            senderId = "ai_bot",
            senderName = "Ax AI Assistant",
            text = response,
            timestamp = timeNow,
            isOutgoing = false
        )
        aiFlow.value = aiFlow.value + aiMsg
    }

    fun addReaction(conversationId: String, messageId: String, reaction: String) {
        val flow = messagesMap[conversationId] ?: return
        flow.value = flow.value.map { msg ->
            if (msg.id == messageId) {
                val newReactions = if (msg.reactions.contains(reaction)) {
                    msg.reactions - reaction
                } else {
                    msg.reactions + reaction
                }
                msg.copy(reactions = newReactions)
            } else msg
        }
    }

    fun deleteMessage(conversationId: String, messageId: String) {
        val flow = messagesMap[conversationId] ?: return
        flow.value = flow.value.filter { it.id != messageId }
    }

    // Scheduled Messages
    private val _scheduledMessages = MutableStateFlow(
        listOf(
            ScheduledMessage(
                id = "sch_1",
                conversationId = "conv_aryan",
                recipientName = "Tech Aryan",
                recipientAvatarRes = R.drawable.avatar_aryan,
                text = "Don't forget to push the release build v3.0.1 tomorrow morning! 🚀",
                scheduledDateStr = "Tomorrow, Nov 7",
                scheduledTimeStr = "09:00 AM",
                isSent = false
            ),
            ScheduledMessage(
                id = "sch_2",
                conversationId = "conv_study_group",
                recipientName = "Study Group",
                recipientAvatarRes = null,
                text = "Reminder: Weekly Android Architecture Sync link will be shared in 10 mins.",
                scheduledDateStr = "Friday, Nov 8",
                scheduledTimeStr = "06:00 PM",
                isSent = false
            )
        )
    )
    val scheduledMessages: StateFlow<List<ScheduledMessage>> = _scheduledMessages.asStateFlow()

    fun scheduleMessage(recipientName: String, text: String, dateStr: String, timeStr: String) {
        val newScheduled = ScheduledMessage(
            id = UUID.randomUUID().toString(),
            conversationId = "conv_ashu",
            recipientName = recipientName,
            recipientAvatarRes = R.drawable.avatar_ashu,
            text = text,
            scheduledDateStr = dateStr,
            scheduledTimeStr = timeStr,
            isSent = false
        )
        _scheduledMessages.value = listOf(newScheduled) + _scheduledMessages.value
    }

    fun cancelScheduledMessage(id: String) {
        _scheduledMessages.value = _scheduledMessages.value.filter { it.id != id }
    }

    fun sendScheduledNow(id: String) {
        val item = _scheduledMessages.value.find { it.id == id } ?: return
        sendMessage(item.conversationId, item.text)
        _scheduledMessages.value = _scheduledMessages.value.map {
            if (it.id == id) it.copy(isSent = true) else it
        }
    }

    // Verification Requests
    private val _verificationRequest = MutableStateFlow<VerificationRequest?>(null)
    val verificationRequest: StateFlow<VerificationRequest?> = _verificationRequest.asStateFlow()

    fun submitVerificationRequest(fullName: String, category: String, documentProof: String) {
        _verificationRequest.value = VerificationRequest(
            id = UUID.randomUUID().toString(),
            fullName = fullName,
            category = category,
            documentProof = documentProof,
            status = VerificationStatus.PENDING,
            submissionDate = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()).format(Date())
        )
    }

    // Notifications
    private val _notifications = MutableStateFlow(
        listOf(
            NotificationItem(
                id = "notif_1",
                title = "Ax Chet v3.0 Released! 🚀",
                message = "Experience glowing borders, scheduled chats, and fast AI responses.",
                time = "10m ago",
                isUnread = true,
                isGoldAdmin = true
            ),
            NotificationItem(
                id = "notif_2",
                title = "Tech Aryan sent a message",
                message = "Thanks bro! 👍",
                time = "30m ago",
                isUnread = true
            ),
            NotificationItem(
                id = "notif_3",
                title = "Gamer Priya started streaming",
                message = "Check out the live stream update in stories.",
                time = "2h ago",
                isUnread = false
            ),
            NotificationItem(
                id = "notif_4",
                title = "Scheduled Message queued",
                message = "Your scheduled message to Tech Aryan is set for tomorrow at 09:00 AM.",
                time = "3h ago",
                isUnread = false
            )
        )
    )
    val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    fun markNotificationsAsRead() {
        _notifications.value = _notifications.value.map { it.copy(isUnread = false) }
    }

    fun updateProfile(name: String, username: String, bio: String) {
        _currentUser.value = _currentUser.value.copy(
            name = name,
            username = username,
            bio = bio
        )
    }

    fun searchUsers(query: String): List<User> {
        if (query.isBlank()) return allUsers
        val cleanQuery = query.trim().removePrefix("@").lowercase()
        return allUsers.filter {
            it.name.lowercase().contains(cleanQuery) ||
                    it.username.lowercase().contains(cleanQuery) ||
                    it.bio.lowercase().contains(cleanQuery)
        }
    }
}
