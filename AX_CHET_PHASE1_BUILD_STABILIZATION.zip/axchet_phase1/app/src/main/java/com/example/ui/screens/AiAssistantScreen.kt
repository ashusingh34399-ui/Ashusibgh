package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AxChetRepository
import com.example.ui.components.BlueVerifiedBadge
import com.example.ui.theme.AxBorderGlow
import com.example.ui.theme.AxBrightViolet
import com.example.ui.theme.AxDeepBlack
import com.example.ui.theme.AxNeonViolet
import com.example.ui.theme.AxSoftPurple
import com.example.ui.theme.AxTextDim
import com.example.ui.theme.AxTextMuted
import com.example.ui.theme.AxWhite

@Composable
fun AiAssistantScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val messagesFlow = remember { AxChetRepository.getMessagesForConversation("ai_assistant") }
    val messages by messagesFlow.collectAsState()
    val listState = rememberLazyListState()
    var inputText by remember { mutableStateOf("") }

    val quickPrompts = listOf(
        "✍️ Draft polite professional message",
        "💻 Android Jetpack Compose example",
        "🌐 Translate message to Hindi",
        "⚡ Summarize chat conversation",
        "👑 How to get Gold Admin badge?"
    )

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AxDeepBlack)
    ) {
        // AI Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
                .background(Color(0xFF110821))
                .border(
                    1.dp,
                    Brush.verticalGradient(listOf(Color.Transparent, AxBorderGlow)),
                    RoundedCornerShape(0.dp)
                )
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = AxWhite
                    )
                }

                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(
                                    Color(0xFF4C1D95),
                                    Color(0xFF7C3AED)
                                )
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.SmartToy,
                        contentDescription = null,
                        tint = AxWhite,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Ax AI Assistant",
                            color = AxWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        BlueVerifiedBadge(size = 14.dp)
                    }
                    Text(
                        text = "Secure Edge Function • Active",
                        color = AxBrightViolet,
                        fontSize = 11.sp
                    )
                }
            }

            IconButton(onClick = {
                // Clear AI chat
                val flow = AxChetRepository.getMessagesForConversation("ai_assistant")
            }) {
                Icon(
                    imageVector = Icons.Default.DeleteSweep,
                    contentDescription = "Clear Chat",
                    tint = AxTextMuted
                )
            }
        }

        // Messages
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                val isOut = msg.isOutgoing
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isOut) Arrangement.End else Arrangement.Start
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(if (isOut) 0.8f else 0.88f)
                            .clip(
                                RoundedCornerShape(
                                    topStart = 16.dp,
                                    topEnd = 16.dp,
                                    bottomStart = if (isOut) 16.dp else 4.dp,
                                    bottomEnd = if (isOut) 4.dp else 16.dp
                                )
                            )
                            .background(
                                if (isOut) Brush.linearGradient(listOf(AxBrightViolet, AxNeonViolet))
                                else Brush.linearGradient(listOf(Color(0xFF19102B), Color(0xFF22163D)))
                            )
                            .border(
                                1.dp,
                                if (isOut) Color.Transparent else AxBorderGlow,
                                RoundedCornerShape(
                                    topStart = 16.dp,
                                    topEnd = 16.dp,
                                    bottomStart = if (isOut) 16.dp else 4.dp,
                                    bottomEnd = if (isOut) 4.dp else 16.dp
                                )
                            )
                            .padding(14.dp)
                    ) {
                        Column {
                            if (!isOut) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(bottom = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AutoAwesome,
                                        contentDescription = null,
                                        tint = AxBrightViolet,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "AI Response",
                                        color = AxSoftPurple,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(
                                text = msg.text,
                                color = AxWhite,
                                fontSize = 14.sp,
                                lineHeight = 20.sp
                            )
                            Text(
                                text = msg.timestamp,
                                color = if (isOut) Color(0xFFE9D5FF) else AxTextDim,
                                fontSize = 10.sp,
                                modifier = Modifier.align(Alignment.End)
                            )
                        }
                    }
                }
            }
        }

        // Quick prompt chips
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(quickPrompts) { prompt ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF180F2E))
                        .border(1.dp, AxBorderGlow, RoundedCornerShape(16.dp))
                        .clickable {
                            AxChetRepository.sendMessage("ai_assistant", prompt)
                        }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = prompt,
                        color = AxTextMuted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Input bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF0D0717))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Ask Ax AI anything...", color = AxTextMuted, fontSize = 14.sp) },
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .testTag("ai_input_field"),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF160E28),
                    unfocusedContainerColor = Color(0xFF160E28),
                    focusedIndicatorColor = AxBrightViolet,
                    unfocusedIndicatorColor = Color(0xFF281A45),
                    focusedTextColor = AxWhite,
                    unfocusedTextColor = AxWhite
                ),
                maxLines = 3
            )

            Spacer(modifier = Modifier.width(8.dp))

            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(AxNeonViolet)
                    .clickable {
                        if (inputText.isNotBlank()) {
                            AxChetRepository.sendMessage("ai_assistant", inputText)
                            inputText = ""
                        }
                    }
                    .testTag("btn_send_ai"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send",
                    tint = AxWhite,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
