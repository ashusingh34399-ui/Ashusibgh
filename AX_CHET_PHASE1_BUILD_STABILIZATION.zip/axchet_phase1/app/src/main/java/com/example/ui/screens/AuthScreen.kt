package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.AxChetRepository
import com.example.ui.theme.AxBorderGlow
import com.example.ui.theme.AxBrightViolet
import com.example.ui.theme.AxDeepBlack
import com.example.ui.theme.AxNeonViolet
import com.example.ui.theme.AxSoftPurple
import com.example.ui.theme.AxTextDim
import com.example.ui.theme.AxTextMuted
import com.example.ui.theme.AxWhite

@Composable
fun AuthScreen(
    onAuthSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showLoginDialog by remember { mutableStateOf(false) }
    var showSignUpDialog by remember { mutableStateOf(false) }
    var authMethod by remember { mutableStateOf("Email") }

    val bgGradient = Brush.verticalGradient(
        listOf(
            Color(0xFF1B0B33),
            Color(0xFF0F071D),
            AxDeepBlack,
            AxDeepBlack
        )
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(bgGradient)
            .padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Glowing Logo Card
            Box(
                modifier = Modifier
                    .size(110.dp)
                    .shadow(32.dp, CircleShape, spotColor = AxBrightViolet)
                    .clip(RoundedCornerShape(32.dp))
                    .background(Color(0xFF1E133A))
                    .border(2.dp, AxBrightViolet.copy(alpha = 0.6f), RoundedCornerShape(32.dp)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_axchet_logo),
                    contentDescription = "Ax Chet Logo",
                    modifier = Modifier.size(90.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // App Title
            Text(
                text = "Ax Chet",
                color = AxWhite,
                fontSize = 36.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Subtitle matching screenshot
            Text(
                text = "Connect • Chat • AI • Schedule",
                color = AxTextMuted,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(48.dp))

            // Continue with Phone
            AuthPillButton(
                icon = Icons.Default.Phone,
                text = "Continue with Phone",
                testTag = "btn_continue_phone",
                onClick = {
                    authMethod = "Phone"
                    showLoginDialog = true
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Continue with Email
            AuthPillButton(
                icon = Icons.Default.Email,
                text = "Continue with Email",
                testTag = "btn_continue_email",
                onClick = {
                    authMethod = "Email"
                    showLoginDialog = true
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Continue with Google
            GoogleAuthPillButton(
                testTag = "btn_continue_google",
                onClick = {
                    onAuthSuccess()
                }
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Divider "or"
            Row(
                modifier = Modifier.fillMaxWidth(0.85f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                HorizontalDivider(modifier = Modifier.weight(1f), color = Color(0xFF261942))
                Text(
                    text = "  or  ",
                    color = AxTextDim,
                    fontSize = 13.sp
                )
                HorizontalDivider(modifier = Modifier.weight(1f), color = Color(0xFF261942))
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Login Button (Glowing Violet Gradient)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                Color(0xFF19102E),
                                Color(0xFF28134F),
                                Color(0xFF19102E)
                            )
                        )
                    )
                    .border(1.5.dp, AxBrightViolet, RoundedCornerShape(26.dp))
                    .clickable {
                        onAuthSuccess()
                    }
                    .testTag("login_button"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Login",
                    color = AxWhite,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Create Account link
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "New here? ",
                    color = AxTextMuted,
                    fontSize = 14.sp
                )
                Text(
                    text = "Create Account",
                    color = AxBrightViolet,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier
                        .clickable { showSignUpDialog = true }
                        .testTag("create_account_link")
                )
            }
        }

        // Quick Auth / Login Dialog
        if (showLoginDialog) {
            Dialog(onDismissRequest = { showLoginDialog = false }) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color(0xFF160E2A),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AxBorderGlow, RoundedCornerShape(24.dp))
                        .padding(24.dp)
                ) {
                    var inputValue by remember { mutableStateOf("") }
                    var passValue by remember { mutableStateOf("") }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Login with $authMethod",
                            color = AxWhite,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedTextField(
                            value = inputValue,
                            onValueChange = { inputValue = it },
                            label = { Text(if (authMethod == "Phone") "Phone (+91...)" else "Email address") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF100A1F),
                                unfocusedContainerColor = Color(0xFF100A1F),
                                focusedTextColor = AxWhite,
                                unfocusedTextColor = AxWhite
                            ),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = passValue,
                            onValueChange = { passValue = it },
                            label = { Text("Password") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF100A1F),
                                unfocusedContainerColor = Color(0xFF100A1F),
                                focusedTextColor = AxWhite,
                                unfocusedTextColor = AxWhite
                            ),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = {
                                showLoginDialog = false
                                onAuthSuccess()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = AxNeonViolet)
                        ) {
                            Text("Confirm & Continue", color = AxWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // SignUp Dialog
        if (showSignUpDialog) {
            Dialog(onDismissRequest = { showSignUpDialog = false }) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color(0xFF160E2A),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, AxBorderGlow, RoundedCornerShape(24.dp))
                        .padding(24.dp)
                ) {
                    var newName by remember { mutableStateOf("") }
                    var newUsername by remember { mutableStateOf("") }
                    var newBio by remember { mutableStateOf("") }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Create Ax Chet Account",
                            color = AxWhite,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        OutlinedTextField(
                            value = newName,
                            onValueChange = { newName = it },
                            label = { Text("Display Name") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF100A1F),
                                unfocusedContainerColor = Color(0xFF100A1F),
                                focusedTextColor = AxWhite,
                                unfocusedTextColor = AxWhite
                            ),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = newUsername,
                            onValueChange = { newUsername = it },
                            label = { Text("Unique Username (@handle)") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF100A1F),
                                unfocusedContainerColor = Color(0xFF100A1F),
                                focusedTextColor = AxWhite,
                                unfocusedTextColor = AxWhite
                            ),
                            singleLine = true
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = newBio,
                            onValueChange = { newBio = it },
                            label = { Text("Bio (Optional)") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color(0xFF100A1F),
                                unfocusedContainerColor = Color(0xFF100A1F),
                                focusedTextColor = AxWhite,
                                unfocusedTextColor = AxWhite
                            )
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = {
                                if (newName.isNotBlank()) {
                                    val formattedUsername = if (newUsername.startsWith("@")) newUsername else "@$newUsername"
                                    AxChetRepository.updateProfile(newName, formattedUsername, newBio)
                                }
                                showSignUpDialog = false
                                onAuthSuccess()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = AxBrightViolet)
                        ) {
                            Text("Create Account", color = AxWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AuthPillButton(
    icon: ImageVector,
    text: String,
    testTag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(Color(0xFF140D24))
            .border(1.dp, Color(0xFF2C1E4A), RoundedCornerShape(26.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = AxWhite,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = text,
                color = AxWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun GoogleAuthPillButton(
    testTag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(26.dp))
            .background(Color(0xFF140D24))
            .border(1.dp, Color(0xFF2C1E4A), RoundedCornerShape(26.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            // Google 'G' stylized badge
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "G",
                    color = Color(0xFF4285F4),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "Continue with Google",
                color = AxWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
