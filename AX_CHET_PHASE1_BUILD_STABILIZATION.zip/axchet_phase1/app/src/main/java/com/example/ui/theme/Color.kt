package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Ax Chet Premium Cyber Dark Palette
val AxDeepBlack = Color(0xFF080610)
val AxDarkPurpleSurface = Color(0xFF100B1C)
val AxSurfaceVariant = Color(0xFF191329)
val AxBorderGlow = Color(0xFF2C1D4D)
val AxBorderSubtle = Color(0xFF231938)

val AxNeonViolet = Color(0xFF922FFF)
val AxBrightViolet = Color(0xFFB84DFF)
val AxSoftPurple = Color(0xFFD28AFF)

val AxGoldAdmin = Color(0xFFFFC52E)
val AxGoldAdminGlow = Color(0xFFFFDF70)
val AxBlueVerified = Color(0xFF168BFF)

val AxWhite = Color(0xFFFFFFFF)
val AxTextMuted = Color(0xFFBDB5CE)
val AxTextDim = Color(0xFF756D8D)

val AxOnlineGreen = Color(0xFF22C55E)
val AxOfflineGrey = Color(0xFF6B7280)

val AxBubbleIncoming = Color(0xFF1A132C)
val AxBubbleOutgoingStart = Color(0xFF922FFF)
val AxBubbleOutgoingEnd = Color(0xFF6714DB)

val AxCardGradientStart = Color(0xFF1B142F)
val AxCardGradientEnd = Color(0xFF100A1F)
