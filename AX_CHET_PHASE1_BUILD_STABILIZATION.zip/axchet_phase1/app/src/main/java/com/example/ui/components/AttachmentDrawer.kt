package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AxBrightViolet
import com.example.ui.theme.AxNeonViolet
import com.example.ui.theme.AxTextMuted
import com.example.ui.theme.AxWhite

@Composable
fun AttachmentDrawer(
    onGalleryClick: () -> Unit,
    onFileClick: () -> Unit,
    onContactClick: () -> Unit,
    onLocationClick: () -> Unit,
    onScheduleClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val drawerBg = Brush.verticalGradient(
        listOf(
            Color(0xFF19112E),
            Color(0xFF100A1F)
        )
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
            .background(drawerBg)
            .border(
                1.dp,
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF922FFF).copy(alpha = 0.4f),
                        Color.Transparent
                    )
                ),
                RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
            )
            .padding(vertical = 18.dp, horizontal = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            AttachmentActionItem(
                label = "Gallery",
                icon = Icons.Default.Image,
                color = Color(0xFFC084FC),
                onClick = onGalleryClick
            )
            AttachmentActionItem(
                label = "File",
                icon = Icons.Default.Description,
                color = Color(0xFF60A5FA),
                onClick = onFileClick
            )
            AttachmentActionItem(
                label = "Contact",
                icon = Icons.Default.Person,
                color = Color(0xFF34D399),
                onClick = onContactClick
            )
            AttachmentActionItem(
                label = "Location",
                icon = Icons.Default.LocationOn,
                color = Color(0xFFF87171),
                onClick = onLocationClick
            )
            AttachmentActionItem(
                label = "Schedule",
                icon = Icons.Default.CalendarMonth,
                color = Color(0xFFFBBF24),
                onClick = onScheduleClick
            )
        }
    }
}

@Composable
private fun AttachmentActionItem(
    label: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.15f))
                .border(1.dp, color.copy(alpha = 0.5f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            color = AxTextMuted,
            fontSize = 12.sp
        )
    }
}
