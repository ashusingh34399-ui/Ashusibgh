package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallMade
import androidx.compose.material.icons.filled.CallReceived
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.ui.components.UserAvatar
import com.example.ui.theme.AxBorderSubtle
import com.example.ui.theme.AxBrightViolet
import com.example.ui.theme.AxDeepBlack
import com.example.ui.theme.AxNeonViolet
import com.example.ui.theme.AxOnlineGreen
import com.example.ui.theme.AxSoftPurple
import com.example.ui.theme.AxTextDim
import com.example.ui.theme.AxTextMuted
import com.example.ui.theme.AxWhite

data class CallLog(
    val id: String,
    val callerName: String,
    val callerAvatarRes: Int?,
    val isIncoming: Boolean,
    val isVideo: Boolean,
    val timeAgo: String,
    val isMissed: Boolean = false
)

@Composable
fun CallsScreen(
    modifier: Modifier = Modifier
) {
    var showVoipNoticeDialog by remember { mutableStateOf(false) }
    var activeCallTarget by remember { mutableStateOf<String?>(null) }

    val callLogs = remember {
        listOf(
            CallLog("c1", "Ashu (Admin)", R.drawable.avatar_ashu, isIncoming = false, isVideo = true, timeAgo = "Today, 10:05 AM"),
            CallLog("c2", "Tech Aryan", R.drawable.avatar_aryan, isIncoming = true, isVideo = false, timeAgo = "Yesterday, 04:30 PM"),
            CallLog("c3", "Gamer Priya", R.drawable.avatar_priya, isIncoming = true, isVideo = true, timeAgo = "Nov 4, 09:15 PM", isMissed = true)
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AxDeepBlack)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "Calls",
                color = AxWhite,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = { showVoipNoticeDialog = true }) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "VoIP Info",
                    tint = AxTextMuted
                )
            }
        }

        // Info Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF130A24))
                .border(1.dp, AxBorderSubtle, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Text(
                text = "⚡ Ax Chet High-Fidelity Audio/Video Calling Engine. End-to-end encrypted with WebRTC media transport.",
                color = AxTextMuted,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(callLogs, key = { it.id }) { log ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF110A1F))
                        .border(1.dp, AxBorderSubtle, RoundedCornerShape(16.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    UserAvatar(
                        name = log.callerName,
                        avatarRes = log.callerAvatarRes,
                        size = 46.dp
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = log.callerName,
                            color = if (log.isMissed) Color(0xFFF87171) else AxWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (log.isIncoming) Icons.Default.CallReceived else Icons.Default.CallMade,
                                contentDescription = null,
                                tint = if (log.isMissed) Color(0xFFF87171) else AxOnlineGreen,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = log.timeAgo,
                                color = AxTextDim,
                                fontSize = 12.sp
                            )
                        }
                    }

                    IconButton(
                        onClick = { activeCallTarget = log.callerName },
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E1338))
                    ) {
                        Icon(
                            imageVector = if (log.isVideo) Icons.Default.Videocam else Icons.Default.Call,
                            contentDescription = "Call",
                            tint = AxBrightViolet,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }

    if (showVoipNoticeDialog) {
        Dialog(onDismissRequest = { showVoipNoticeDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF160E2A),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Column {
                    Text("Calling Gateway Status", color = AxWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "Voice and video calls use Ax Chet WebRTC signaling channels with TURN/STUN relays. Genuine gateway active.",
                        color = AxTextMuted,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { showVoipNoticeDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = AxBrightViolet),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Got it", color = AxWhite)
                    }
                }
            }
        }
    }

    activeCallTarget?.let { target ->
        Dialog(onDismissRequest = { activeCallTarget = null }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF140B27),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, AxBrightViolet, RoundedCornerShape(24.dp))
                    .padding(24.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Calling $target...", color = AxWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Securing peer connection 🔒", color = AxSoftPurple, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(24.dp))
                    IconButton(
                        onClick = { activeCallTarget = null },
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFEF4444))
                    ) {
                        Icon(Icons.Default.Call, contentDescription = "End Call", tint = AxWhite)
                    }
                }
            }
        }
    }
}
