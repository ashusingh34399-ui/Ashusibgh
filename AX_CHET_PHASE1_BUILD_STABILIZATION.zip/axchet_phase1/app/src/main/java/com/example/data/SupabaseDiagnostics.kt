package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

object SupabaseDiagnostics {
    sealed class Result {
        data class Success(val httpCode: Int) : Result()
        data class ConfigurationError(val message: String) : Result()
        data class InvalidCredentials(val httpCode: Int) : Result()
        data class ServerError(val httpCode: Int) : Result()
        data class NetworkError(val message: String) : Result()
        data class Timeout(val message: String) : Result()
        data class HttpError(val httpCode: Int) : Result()
    }

    internal fun classifyHttpStatus(code: Int): Result = when {
        code in 200..299 -> Result.Success(code)
        code == 401 || code == 403 -> Result.InvalidCredentials(code)
        code in 500..599 -> Result.ServerError(code)
        else -> Result.HttpError(code)
    }

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(10, TimeUnit.SECONDS)
            .callTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    /**
     * Makes a real, read-only request to PostgREST's root endpoint.
     * No database table is queried and no credential is logged or returned.
     */
    suspend fun run(): Result = withContext(Dispatchers.IO) {
        val configuration = when (val config = SupabaseProvider.loadConfiguration()) {
            is SupabaseProvider.ConfigurationResult.Valid -> config.configuration
            is SupabaseProvider.ConfigurationResult.Invalid ->
                return@withContext Result.ConfigurationError(config.reason)
        }

        try {
            // Force lazy SDK initialization before performing the HTTP connectivity check.
            SupabaseProvider.client

            val request = Request.Builder()
                .url("${configuration.url}/rest/v1/")
                .header("apikey", configuration.publishableKey)
                .header("Accept", "application/openapi+json")
                .get()
                .build()

            httpClient.newCall(request).execute().use { response ->
                classifyHttpStatus(response.code)
            }
        } catch (error: SocketTimeoutException) {
            Result.Timeout("The Supabase request timed out.")
        } catch (error: UnknownHostException) {
            Result.NetworkError("No internet connection or the Supabase host could not be resolved.")
        } catch (error: IOException) {
            Result.NetworkError("A network error prevented the Supabase connection.")
        } catch (error: IllegalStateException) {
            Result.ConfigurationError(error.message ?: "Supabase configuration is invalid.")
        } catch (error: Exception) {
            Result.NetworkError("Supabase initialization or connection failed.")
        }
    }
}
