package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AxChetRepository
import com.example.model.User
import com.example.ui.components.BlueVerifiedBadge
import com.example.ui.components.GoldAdminBadge
import com.example.ui.components.UserAvatar
import com.example.ui.theme.AxBorderGlow
import com.example.ui.theme.AxBorderSubtle
import com.example.ui.theme.AxBrightViolet
import com.example.ui.theme.AxDeepBlack
import com.example.ui.theme.AxNeonViolet
import com.example.ui.theme.AxSoftPurple
import com.example.ui.theme.AxTextDim
import com.example.ui.theme.AxTextMuted
import com.example.ui.theme.AxWhite

@Composable
fun UsernameSearchScreen(
    onBack: () -> Unit,
    onUserSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    val searchResults = remember(searchQuery) { AxChetRepository.searchUsers(searchQuery) }
    val recentSearches = listOf("@ax_ashu", "@tech_aryan", "@gamer_priya", "@ax_updates")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AxDeepBlack)
    ) {
        // Search Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = AxWhite
                )
            }

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by @username or name...", color = AxTextMuted, fontSize = 14.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = AxBrightViolet
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = AxTextMuted)
                        }
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .testTag("username_search_input"),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFF140D24),
                    unfocusedContainerColor = Color(0xFF140D24),
                    focusedIndicatorColor = AxBrightViolet,
                    unfocusedIndicatorColor = Color(0xFF281C45),
                    focusedTextColor = AxWhite,
                    unfocusedTextColor = AxWhite
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.width(8.dp))
        }

        // Recent searches chips
        if (searchQuery.isEmpty()) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Text(
                    text = "Recent Searches",
                    color = AxTextDim,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(recentSearches) { tag ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFF160E28))
                                .border(1.dp, AxBorderSubtle, RoundedCornerShape(14.dp))
                                .clickable { searchQuery = tag }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(text = tag, color = AxSoftPurple, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Search Results List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(searchResults, key = { it.id }) { user ->
                UserSearchResultCard(
                    user = user,
                    onMessageClick = {
                        val convId = when {
                            user.id.contains("ashu") -> "conv_ashu"
                            user.id.contains("aryan") -> "conv_aryan"
                            user.id.contains("priya") -> "conv_priya"
                            user.id.contains("updates") -> "conv_ax_updates"
                            else -> "conv_ashu"
                        }
                        onUserSelected(convId)
                    }
                )
            }
        }
    }
}

@Composable
private fun UserSearchResultCard(
    user: User,
    onMessageClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF130B22))
            .border(1.dp, AxBorderSubtle, RoundedCornerShape(16.dp))
            .clickable(onClick = onMessageClick)
            .padding(12.dp)
            .testTag("user_search_card_${user.username}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        UserAvatar(
            name = user.name,
            avatarRes = user.avatarRes,
            size = 48.dp,
            isGoldAdmin = user.isGoldAdmin,
            isBlueVerified = user.isBlueVerified,
            isOnline = user.isOnline
        )

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = user.name,
                    color = AxWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                if (user.isGoldAdmin) {
                    Spacer(modifier = Modifier.width(6.dp))
                    GoldAdminBadge(size = 16.dp)
                } else if (user.isBlueVerified) {
                    Spacer(modifier = Modifier.width(6.dp))
                    BlueVerifiedBadge(size = 14.dp)
                }
            }
            Text(
                text = user.username,
                color = AxBrightViolet,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            if (user.bio.isNotBlank()) {
                Text(
                    text = user.bio,
                    color = AxTextMuted,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        Button(
            onClick = onMessageClick,
            colors = ButtonDefaults.buttonColors(containerColor = AxNeonViolet),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            modifier = Modifier.height(34.dp)
        ) {
            Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Chat", color = AxWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}
