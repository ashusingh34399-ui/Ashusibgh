package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.AxChetRepository
import com.example.ui.components.AxChetBottomBar
import com.example.ui.components.BottomNavTab
import com.example.ui.screens.AiAssistantScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CallsScreen
import com.example.ui.screens.ChatDetailScreen
import com.example.ui.screens.MainChatsScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ScheduledMessagesScreen
import com.example.ui.screens.UsernameSearchScreen
import com.example.ui.screens.VerificationScreen
import com.example.ui.theme.AxBorderGlow
import com.example.ui.theme.AxBorderSubtle
import com.example.ui.theme.AxBrightViolet
import com.example.ui.theme.AxChetTheme
import com.example.ui.theme.AxDeepBlack
import com.example.ui.theme.AxNeonViolet
import com.example.ui.theme.AxTextMuted
import com.example.ui.theme.AxWhite

sealed class Screen {
    object Auth : Screen()
    object Main : Screen()
    data class ChatDetail(val conversationId: String) : Screen()
    object Search : Screen()
    object Notifications : Screen()
    object Verification : Screen()
    object AiAssistant : Screen()
    object Scheduled : Screen()
    object Profile : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AxChetTheme {
                AxChetApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AxChetApp() {
    val context = LocalContext.current
    var currentScreen by remember { mutableStateOf<Screen>(Screen.Main) }
    var selectedTab by remember { mutableStateOf(BottomNavTab.CHATS) }
    var showCreateSheet by remember { mutableStateOf(false) }
    var showNewGroupDialog by remember { mutableStateOf(false) }
    var showNewChannelDialog by remember { mutableStateOf(false) }

    val createSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Back handling
    if (currentScreen != Screen.Main && currentScreen != Screen.Auth) {
        BackHandler {
            currentScreen = Screen.Main
        }
    }

    AnimatedContent(
        targetState = currentScreen,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "screenTransition"
    ) { screen ->
        when (screen) {
            is Screen.Auth -> {
                AuthScreen(
                    onAuthSuccess = {
                        currentScreen = Screen.Main
                    }
                )
            }

            is Screen.ChatDetail -> {
                ChatDetailScreen(
                    conversationId = screen.conversationId,
                    onBack = { currentScreen = Screen.Main },
                    onOpenProfile = { currentScreen = Screen.Profile }
                )
            }

            is Screen.Search -> {
                UsernameSearchScreen(
                    onBack = { currentScreen = Screen.Main },
                    onUserSelected = { convId ->
                        currentScreen = Screen.ChatDetail(convId)
                    }
                )
            }

            is Screen.Notifications -> {
                NotificationsScreen(
                    onBack = { currentScreen = Screen.Main }
                )
            }

            is Screen.Verification -> {
                VerificationScreen(
                    onBack = { currentScreen = Screen.Main }
                )
            }

            is Screen.AiAssistant -> {
                AiAssistantScreen(
                    onBack = { currentScreen = Screen.Main }
                )
            }

            is Screen.Scheduled -> {
                ScheduledMessagesScreen(
                    onBack = { currentScreen = Screen.Main }
                )
            }

            is Screen.Profile -> {
                ProfileScreen(
                    onBack = { currentScreen = Screen.Main },
                    onScheduledClick = { currentScreen = Screen.Scheduled },
                    onVerificationClick = { currentScreen = Screen.Verification },
                    onAiSettingsClick = { currentScreen = Screen.AiAssistant }
                )
            }

            is Screen.Main -> {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = AxDeepBlack,
                    bottomBar = {
                        AxChetBottomBar(
                            selectedTab = selectedTab,
                            onTabSelected = { tab ->
                                selectedTab = tab
                            },
                            onFabClick = {
                                showCreateSheet = true
                            }
                        )
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (selectedTab) {
                            BottomNavTab.CHATS -> {
                                MainChatsScreen(
                                    onConversationClick = { convId ->
                                        if (convId == "ai_assistant") {
                                            currentScreen = Screen.AiAssistant
                                        } else {
                                            currentScreen = Screen.ChatDetail(convId)
                                        }
                                    },
                                    onSearchClick = { currentScreen = Screen.Search },
                                    onNotificationsClick = { currentScreen = Screen.Notifications },
                                    onVerificationClick = { currentScreen = Screen.Verification },
                                    onScheduledClick = { currentScreen = Screen.Scheduled },
                                    onLogout = { currentScreen = Screen.Auth }
                                )
                            }

                            BottomNavTab.CALLS -> {
                                CallsScreen()
                            }

                            BottomNavTab.SCHEDULE -> {
                                ScheduledMessagesScreen(
                                    onBack = { selectedTab = BottomNavTab.CHATS }
                                )
                            }

                            BottomNavTab.PROFILE -> {
                                ProfileScreen(
                                    onBack = { selectedTab = BottomNavTab.CHATS },
                                    onScheduledClick = { currentScreen = Screen.Scheduled },
                                    onVerificationClick = { currentScreen = Screen.Verification },
                                    onAiSettingsClick = { currentScreen = Screen.AiAssistant }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Center FAB Create Bottom Sheet
    if (showCreateSheet) {
        ModalBottomSheet(
            onDismissRequest = { showCreateSheet = false },
            sheetState = createSheetState,
            containerColor = Color(0xFF140C26),
            contentColor = AxWhite
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "Create in Ax Chet",
                    color = AxWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(16.dp))

                CreateOptionItem(
                    icon = Icons.Default.Chat,
                    title = "New Direct Chat",
                    subtitle = "Search by unique @username",
                    color = AxBrightViolet,
                    onClick = {
                        showCreateSheet = false
                        currentScreen = Screen.Search
                    }
                )

                CreateOptionItem(
                    icon = Icons.Default.GroupAdd,
                    title = "New Group",
                    subtitle = "Collaborate with up to 200,000 members",
                    color = Color(0xFF60A5FA),
                    onClick = {
                        showCreateSheet = false
                        showNewGroupDialog = true
                    }
                )

                CreateOptionItem(
                    icon = Icons.Default.Campaign,
                    title = "New Broadcast Channel",
                    subtitle = "One-to-many announcements and updates",
                    color = Color(0xFF34D399),
                    onClick = {
                        showCreateSheet = false
                        showNewChannelDialog = true
                    }
                )

                CreateOptionItem(
                    icon = Icons.Default.Schedule,
                    title = "Schedule Message",
                    subtitle = "Automated background delivery",
                    color = Color(0xFFFBBF24),
                    onClick = {
                        showCreateSheet = false
                        currentScreen = Screen.Scheduled
                    }
                )

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // New Group Dialog
    if (showNewGroupDialog) {
        Dialog(onDismissRequest = { showNewGroupDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF160E2A),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AxBorderGlow, RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                var groupName by remember { mutableStateOf("") }
                var groupDesc by remember { mutableStateOf("") }

                Column {
                    Text("Create New Group", color = AxWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedTextField(
                        value = groupName,
                        onValueChange = { groupName = it },
                        label = { Text("Group Name") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF100A1F),
                            unfocusedContainerColor = Color(0xFF100A1F),
                            focusedTextColor = AxWhite,
                            unfocusedTextColor = AxWhite
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = groupDesc,
                        onValueChange = { groupDesc = it },
                        label = { Text("Description") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF100A1F),
                            unfocusedContainerColor = Color(0xFF100A1F),
                            focusedTextColor = AxWhite,
                            unfocusedTextColor = AxWhite
                        )
                    )
                    Spacer(modifier = Modifier.height(18.dp))
                    Button(
                        onClick = {
                            if (groupName.isNotBlank()) {
                                showNewGroupDialog = false
                                Toast.makeText(context, "Group '$groupName' created!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = AxBrightViolet)
                    ) {
                        Text("Create Group", color = AxWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // New Channel Dialog
    if (showNewChannelDialog) {
        Dialog(onDismissRequest = { showNewChannelDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF160E2A),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AxBorderGlow, RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                var channelName by remember { mutableStateOf("") }
                var channelHandle by remember { mutableStateOf("") }

                Column {
                    Text("Create Broadcast Channel", color = AxWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedTextField(
                        value = channelName,
                        onValueChange = { channelName = it },
                        label = { Text("Channel Name") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF100A1F),
                            unfocusedContainerColor = Color(0xFF100A1F),
                            focusedTextColor = AxWhite,
                            unfocusedTextColor = AxWhite
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = channelHandle,
                        onValueChange = { channelHandle = it },
                        label = { Text("Channel Handle (@channel_name)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF100A1F),
                            unfocusedContainerColor = Color(0xFF100A1F),
                            focusedTextColor = AxWhite,
                            unfocusedTextColor = AxWhite
                        )
                    )
                    Spacer(modifier = Modifier.height(18.dp))
                    Button(
                        onClick = {
                            if (channelName.isNotBlank()) {
                                showNewChannelDialog = false
                                Toast.makeText(context, "Channel '$channelName' created!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF34D399))
                    ) {
                        Text("Create Channel", color = Color(0xFF080610), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun CreateOptionItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    color: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.15f))
                .border(1.dp, color.copy(alpha = 0.4f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(22.dp)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column {
            Text(
                text = title,
                color = AxWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                color = AxTextMuted,
                fontSize = 12.sp
            )
        }
    }
}
