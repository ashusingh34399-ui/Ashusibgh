package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.AxChetRepository
import com.example.ui.components.AdminRolePill
import com.example.ui.components.BlueVerifiedBadge
import com.example.ui.components.GoldAdminBadge
import com.example.ui.components.UserAvatar
import com.example.ui.theme.AxBlueVerified
import com.example.ui.theme.AxBorderGlow
import com.example.ui.theme.AxBorderSubtle
import com.example.ui.theme.AxBrightViolet
import com.example.ui.theme.AxDeepBlack
import com.example.ui.theme.AxNeonViolet
import com.example.ui.theme.AxSoftPurple
import com.example.ui.theme.AxTextDim
import com.example.ui.theme.AxTextMuted
import com.example.ui.theme.AxWhite

@Composable
fun ProfileScreen(
    onBack: () -> Unit,
    onScheduledClick: () -> Unit,
    onVerificationClick: () -> Unit,
    onAiSettingsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentUser by AxChetRepository.currentUser.collectAsState()

    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showQrDialog by remember { mutableStateOf(false) }
    var showThemeDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showApiDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AxDeepBlack)
            .verticalScroll(rememberScrollState())
    ) {
        // Top Bar matching Screenshot 4
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(58.dp)
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = AxWhite
                )
            }
            Text(
                text = "Profile",
                color = AxWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = { showEditProfileDialog = true }) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "Edit Profile",
                    tint = AxWhite
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Center Profile Avatar and Header
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Large Glowing Avatar with Gold A Shield badge matching Screenshot 4
            Box(
                contentAlignment = Alignment.Center
            ) {
                UserAvatar(
                    name = currentUser.name,
                    avatarRes = currentUser.avatarRes,
                    size = 110.dp,
                    isGoldAdmin = false, // attached manually below for precise positioning
                    isBlueVerified = false,
                    ringGlow = true
                )

                if (currentUser.isGoldAdmin) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .offset(x = (-4).dp, y = (-4).dp)
                    ) {
                        GoldAdminBadge(size = 32.dp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Name + Blue Check
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = currentUser.name,
                    color = AxWhite,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                if (currentUser.isBlueVerified) {
                    Spacer(modifier = Modifier.width(8.dp))
                    BlueVerifiedBadge(size = 20.dp)
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Username
            Text(
                text = currentUser.username,
                color = AxTextMuted,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Admin Role Pill
            currentUser.roleTitle?.let { role ->
                AdminRolePill(roleTitle = role)
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Bio
            Text(
                text = currentUser.bio,
                color = AxWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Stats Row: Posts | Followers | Following
            Row(
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF130A24))
                    .border(1.dp, AxBorderSubtle, RoundedCornerShape(16.dp))
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatColumn(count = currentUser.postsCount, label = "Posts")
                Box(modifier = Modifier.size(1.dp, 28.dp).background(Color(0xFF281C45)))
                StatColumn(count = currentUser.followersCount, label = "Followers")
                Box(modifier = Modifier.size(1.dp, 28.dp).background(Color(0xFF281C45)))
                StatColumn(count = currentUser.followingCount, label = "Following")
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Options List matching Screenshot 4
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF110B1E))
                .border(1.dp, Color(0xFF201538), RoundedCornerShape(20.dp))
        ) {
            ProfileMenuOption(
                icon = Icons.Default.Person,
                title = "My Account",
                onClick = { showEditProfileDialog = true }
            )
            HorizontalDivider(color = Color(0xFF1C1333))

            // Verification Option with "Request" Button & Blue Check
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onVerificationClick)
                    .padding(horizontal = 16.dp, vertical = 14.dp)
                    .testTag("menu_verification"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Verified,
                    contentDescription = null,
                    tint = AxBlueVerified,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Verification",
                        color = AxWhite,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    BlueVerifiedBadge(size = 14.dp)
                }

                // "Request" button in gradient violet
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(AxNeonViolet)
                        .clickable(onClick = onVerificationClick)
                        .padding(horizontal = 12.dp, vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Request",
                        color = AxWhite,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            HorizontalDivider(color = Color(0xFF1C1333))

            ProfileMenuOption(
                icon = Icons.Default.CalendarMonth,
                title = "Scheduled Chats",
                onClick = onScheduledClick
            )
            HorizontalDivider(color = Color(0xFF1C1333))

            ProfileMenuOption(
                icon = Icons.Default.Security,
                title = "Privacy & Security",
                onClick = { showPrivacyDialog = true }
            )
            HorizontalDivider(color = Color(0xFF1C1333))

            ProfileMenuOption(
                icon = Icons.Default.Palette,
                title = "Theme & Appearance",
                onClick = { showThemeDialog = true }
            )
            HorizontalDivider(color = Color(0xFF1C1333))

            ProfileMenuOption(
                icon = Icons.Default.SmartToy,
                title = "AI Settings",
                onClick = onAiSettingsClick
            )
            HorizontalDivider(color = Color(0xFF1C1333))

            ProfileMenuOption(
                icon = Icons.Default.Code,
                title = "API & MCP (Advanced)",
                onClick = { showApiDialog = true }
            )
            HorizontalDivider(color = Color(0xFF1C1333))

            ProfileMenuOption(
                icon = Icons.Default.QrCode,
                title = "Share Profile QR",
                onClick = { showQrDialog = true }
            )
            HorizontalDivider(color = Color(0xFF1C1333))

            ProfileMenuOption(
                icon = Icons.Default.HelpOutline,
                title = "Help & Support",
                onClick = {
                    Toast.makeText(context, "Support desk: support@axchet.io", Toast.LENGTH_SHORT).show()
                }
            )
            HorizontalDivider(color = Color(0xFF1C1333))

            ProfileMenuOption(
                icon = Icons.Default.Info,
                title = "About Ax Chet",
                onClick = { showAboutDialog = true }
            )
        }

        Spacer(modifier = Modifier.height(32.dp))
    }

    // Edit Profile Dialog
    if (showEditProfileDialog) {
        Dialog(onDismissRequest = { showEditProfileDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF160E2A),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AxBorderGlow, RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                var editName by remember { mutableStateOf(currentUser.name) }
                var editUsername by remember { mutableStateOf(currentUser.username) }
                var editBio by remember { mutableStateOf(currentUser.bio) }

                Column {
                    Text("Edit Profile", color = AxWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(14.dp))
                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Display Name") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF100A1F),
                            unfocusedContainerColor = Color(0xFF100A1F),
                            focusedTextColor = AxWhite,
                            unfocusedTextColor = AxWhite
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = editUsername,
                        onValueChange = { editUsername = it },
                        label = { Text("Username") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF100A1F),
                            unfocusedContainerColor = Color(0xFF100A1F),
                            focusedTextColor = AxWhite,
                            unfocusedTextColor = AxWhite
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = editBio,
                        onValueChange = { editBio = it },
                        label = { Text("Bio") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF100A1F),
                            unfocusedContainerColor = Color(0xFF100A1F),
                            focusedTextColor = AxWhite,
                            unfocusedTextColor = AxWhite
                        )
                    )
                    Spacer(modifier = Modifier.height(18.dp))
                    Button(
                        onClick = {
                            AxChetRepository.updateProfile(editName, editUsername, editBio)
                            showEditProfileDialog = false
                            Toast.makeText(context, "Profile updated!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = AxBrightViolet)
                    ) {
                        Text("Save Changes", color = AxWhite, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // QR Share Dialog
    if (showQrDialog) {
        Dialog(onDismissRequest = { showQrDialog = false }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF150B27),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, AxBrightViolet, RoundedCornerShape(24.dp))
                    .padding(24.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Ax Chet Profile QR", color = AxWhite, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Scan to start chatting with ${currentUser.name}", color = AxTextMuted, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(20.dp))

                    // QR Code graphic representation
                    Box(
                        modifier = Modifier
                            .size(200.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color.White)
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.QrCode,
                                contentDescription = "QR Code",
                                tint = Color(0xFF080610),
                                modifier = Modifier.size(130.dp)
                            )
                            Text(
                                text = currentUser.username,
                                color = Color(0xFF080610),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = { showQrDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = AxNeonViolet)
                    ) {
                        Text("Close", color = AxWhite)
                    }
                }
            }
        }
    }

    // API & MCP Dialog
    if (showApiDialog) {
        Dialog(onDismissRequest = { showApiDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF160E2A),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AxBorderGlow, RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                Column {
                    Text("API & Supabase Integration", color = AxWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "• Supabase Backend: PostgreSQL & Realtime active\n• Auth: Token Session & Google Sign-In\n• Edge Functions: Cron scheduler & AI router\n• Zero Trust RLS: Enabled\n• Gold Admin Authorization: Hardware-verified backend claim",
                        color = AxTextMuted,
                        fontSize = 13.sp,
                        lineHeight = 20.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { showApiDialog = false },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = AxNeonViolet)
                    ) {
                        Text("Done", color = AxWhite)
                    }
                }
            }
        }
    }

    // Theme Dialog
    if (showThemeDialog) {
        Dialog(onDismissRequest = { showThemeDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF160E2A),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AxBorderGlow, RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                Column {
                    Text("Theme & Appearance", color = AxWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(14.dp))
                    listOf(
                        "Midnight Dark (Default)" to true,
                        "Neon Cyber Violet" to false,
                        "Royal Gradient" to false,
                        "Clean Light" to false
                    ).forEach { (themeName, selected) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    showThemeDialog = false
                                    Toast.makeText(context, "$themeName selected", Toast.LENGTH_SHORT).show()
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = themeName,
                                color = if (selected) AxBrightViolet else AxWhite,
                                fontSize = 15.sp,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.weight(1f)
                            )
                            if (selected) {
                                BlueVerifiedBadge(size = 16.dp)
                            }
                        }
                    }
                }
            }
        }
    }

    // Privacy Dialog
    if (showPrivacyDialog) {
        Dialog(onDismissRequest = { showPrivacyDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF160E2A),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AxBorderGlow, RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                Column {
                    Text("Privacy & Security", color = AxWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("• Last Seen: Everyone", color = AxWhite, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("• Email Privacy: Hidden", color = AxWhite, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("• Phone Privacy: Contacts Only", color = AxWhite, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("• Blocked Users: 0", color = AxWhite, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(18.dp))
                    Button(
                        onClick = { showPrivacyDialog = false },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = AxBrightViolet)
                    ) {
                        Text("Save Preferences", color = AxWhite)
                    }
                }
            }
        }
    }

    // About Dialog
    if (showAboutDialog) {
        Dialog(onDismissRequest = { showAboutDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF160E2A),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AxBorderGlow, RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Ax Chet", color = AxWhite, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Version 3.0.0 (Build 300)", color = AxTextMuted, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Premium native messaging and intelligent AI assistant engineered with Jetpack Compose, edge-to-edge support, and real-time backend synchronization.",
                        color = AxTextMuted,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(18.dp))
                    Button(
                        onClick = { showAboutDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = AxBrightViolet)
                    ) {
                        Text("OK", color = AxWhite)
                    }
                }
            }
        }
    }
}

@Composable
private fun StatColumn(count: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = count, color = AxWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(text = label, color = AxTextMuted, fontSize = 12.sp)
    }
}

@Composable
private fun ProfileMenuOption(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = AxTextMuted,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = title,
            color = AxWhite,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f)
        )
        Icon(
            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = AxTextDim,
            modifier = Modifier.size(20.dp)
        )
    }
}
