package com.example.data

import com.example.BuildConfig
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.functions.Functions
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.realtime.Realtime
import io.github.jan.supabase.storage.Storage

/**
 * Centralized, lazily initialized Supabase client.
 * Only the public client key is packaged; database authorization must be enforced with RLS.
 */
object SupabaseProvider {
    data class Configuration(
        val url: String,
        val publishableKey: String
    )

    sealed class ConfigurationResult {
        data class Valid(val configuration: Configuration) : ConfigurationResult()
        data class Invalid(val reason: String) : ConfigurationResult()
    }

    fun loadConfiguration(
        url: String = BuildConfig.SUPABASE_URL,
        publishableKey: String = BuildConfig.SUPABASE_PUBLISHABLE_KEY
    ): ConfigurationResult {
        if (url.isBlank() || url == "YOUR_SUPABASE_URL") {
            return ConfigurationResult.Invalid("Supabase URL is missing. Set SUPABASE_URL in the project .env file.")
        }
        if (publishableKey.isBlank() || publishableKey == "YOUR_SUPABASE_PUBLISHABLE_KEY") {
            return ConfigurationResult.Invalid("Supabase publishable key is missing. Set SUPABASE_PUBLISHABLE_KEY in the project .env file.")
        }
        val parsed = runCatching { java.net.URI(url) }.getOrNull()
        if (parsed == null || parsed.scheme != "https" || parsed.host.isNullOrBlank() ||
            parsed.rawUserInfo != null || parsed.rawQuery != null || parsed.rawFragment != null
        ) {
            return ConfigurationResult.Invalid("Supabase URL is invalid. Use a valid HTTPS project URL.")
        }
        return ConfigurationResult.Valid(Configuration(url.trimEnd('/'), publishableKey))
    }

    val client by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        val configuration = when (val result = loadConfiguration()) {
            is ConfigurationResult.Valid -> result.configuration
            is ConfigurationResult.Invalid -> throw IllegalStateException(result.reason)
        }
        createSupabaseClient(
            supabaseUrl = configuration.url,
            supabaseKey = configuration.publishableKey
        ) {
            install(Auth)
            install(Postgrest)
            install(Realtime)
            install(Storage)
            install(Functions)
        }
    }
}
