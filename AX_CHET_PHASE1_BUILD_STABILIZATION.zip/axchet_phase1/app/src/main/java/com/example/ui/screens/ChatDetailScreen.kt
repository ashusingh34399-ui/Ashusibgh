package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.SentimentSatisfiedAlt
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.AxChetRepository
import com.example.model.Message
import com.example.model.MessageType
import com.example.ui.components.AttachmentDrawer
import com.example.ui.components.BlueVerifiedBadge
import com.example.ui.components.GoldAdminBadge
import com.example.ui.components.OnlineStatusIndicator
import com.example.ui.components.UserAvatar
import com.example.ui.theme.AxBorderGlow
import com.example.ui.theme.AxBorderSubtle
import com.example.ui.theme.AxBrightViolet
import com.example.ui.theme.AxBubbleIncoming
import com.example.ui.theme.AxBubbleOutgoingEnd
import com.example.ui.theme.AxBubbleOutgoingStart
import com.example.ui.theme.AxDeepBlack
import com.example.ui.theme.AxNeonViolet
import com.example.ui.theme.AxOnlineGreen
import com.example.ui.theme.AxSoftPurple
import com.example.ui.theme.AxTextDim
import com.example.ui.theme.AxTextMuted
import com.example.ui.theme.AxWhite

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatDetailScreen(
    conversationId: String,
    onBack: () -> Unit,
    onOpenProfile: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val conversations by AxChetRepository.conversations.collectAsState()
    val conv = conversations.find { it.id == conversationId } ?: conversations.first()
    val messagesFlow = remember(conversationId) { AxChetRepository.getMessagesForConversation(conversationId) }
    val messages by messagesFlow.collectAsState()
    val listState = rememberLazyListState()

    var inputText by remember { mutableStateOf("") }
    var showAttachmentDrawer by remember { mutableStateOf(false) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var selectedMessageForAction by remember { mutableStateOf<Message?>(null) }
    var showScheduleDialog by remember { mutableStateOf(false) }
    var showCallDialog by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(AxDeepBlack)
    ) {
        // Chat Header matching Screenshot 3
        ChatHeader(
            title = conv.title,
            avatarRes = conv.avatarRes,
            isGoldAdmin = conv.isGoldAdmin,
            isBlueVerified = conv.isBlueVerified,
            isOnline = conv.isOnline,
            onBack = onBack,
            onTitleClick = { onOpenProfile(conv.id) },
            onVideoCall = { showCallDialog = "Video Call with ${conv.title}" },
            onAudioCall = { showCallDialog = "Voice Call with ${conv.title}" },
            onMoreClick = { showMoreMenu = true }
        )

        // Dropdown menu
        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.TopEnd) {
            DropdownMenu(
                expanded = showMoreMenu,
                onDismissRequest = { showMoreMenu = false },
                modifier = Modifier
                    .background(Color(0xFF160E2A))
                    .border(1.dp, AxBorderGlow, RoundedCornerShape(8.dp))
            ) {
                DropdownMenuItem(
                    text = { Text("Search Messages", color = AxWhite) },
                    onClick = {
                        showMoreMenu = false
                        Toast.makeText(context, "Search in chat opened", Toast.LENGTH_SHORT).show()
                    }
                )
                DropdownMenuItem(
                    text = { Text("Schedule Message", color = AxWhite) },
                    onClick = {
                        showMoreMenu = false
                        showScheduleDialog = true
                    }
                )
                DropdownMenuItem(
                    text = { Text("Mute Notifications", color = AxWhite) },
                    onClick = {
                        showMoreMenu = false
                        Toast.makeText(context, "Conversation muted", Toast.LENGTH_SHORT).show()
                    }
                )
                DropdownMenuItem(
                    text = { Text("Clear Chat History", color = Color(0xFFF87171)) },
                    onClick = {
                        showMoreMenu = false
                        Toast.makeText(context, "Chat history cleared", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }

        // Messages List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // "Today" Date Pill
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF160F26))
                            .border(1.dp, Color(0xFF261A3D), RoundedCornerShape(12.dp))
                            .padding(horizontal = 14.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "Today",
                            color = AxTextMuted,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            items(messages, key = { it.id }) { msg ->
                MessageBubble(
                    message = msg,
                    onLongClick = { selectedMessageForAction = msg },
                    onDownloadClick = {
                        Toast.makeText(context, "Downloading ${msg.fileName ?: "file"}...", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }

        // Attachment Drawer Animated Sheet
        AnimatedVisibility(
            visible = showAttachmentDrawer,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it })
        ) {
            AttachmentDrawer(
                onGalleryClick = {
                    showAttachmentDrawer = false
                    AxChetRepository.sendMessage(
                        conversationId = conversationId,
                        text = "Shared screenshot photo",
                        type = MessageType.IMAGE
                    )
                },
                onFileClick = {
                    showAttachmentDrawer = false
                    AxChetRepository.sendMessage(
                        conversationId = conversationId,
                        text = "",
                        type = MessageType.FILE,
                        fileName = "AxChet_v3.0.apk",
                        fileSize = "52.4 MB • APK"
                    )
                },
                onContactClick = {
                    showAttachmentDrawer = false
                    AxChetRepository.sendMessage(
                        conversationId = conversationId,
                        text = "👤 Contact: Ashu (Admin) • @ax_ashu",
                        type = MessageType.TEXT
                    )
                },
                onLocationClick = {
                    showAttachmentDrawer = false
                    AxChetRepository.sendMessage(
                        conversationId = conversationId,
                        text = "📍 Live Location: Cyber City Tech Hub",
                        type = MessageType.LOCATION
                    )
                },
                onScheduleClick = {
                    showAttachmentDrawer = false
                    showScheduleDialog = true
                }
            )
        }

        // Bottom Message Input Bar matching Screenshot 3
        ChatInputBar(
            text = inputText,
            onTextChanged = { inputText = it },
            onSendClick = {
                if (inputText.isNotBlank()) {
                    AxChetRepository.sendMessage(conversationId, inputText)
                    inputText = ""
                }
            },
            onAttachClick = { showAttachmentDrawer = !showAttachmentDrawer },
            onCameraClick = {
                AxChetRepository.sendMessage(
                    conversationId = conversationId,
                    text = "Photo sent from Camera 📸",
                    type = MessageType.IMAGE
                )
            },
            onVoiceRecord = {
                AxChetRepository.sendMessage(
                    conversationId = conversationId,
                    text = "",
                    type = MessageType.VOICE,
                    audioDuration = 8
                )
            }
        )
    }

    // Message Actions Dialog (Reactions, Copy, Pin, Delete)
    selectedMessageForAction?.let { msg ->
        Dialog(onDismissRequest = { selectedMessageForAction = null }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF19112E),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AxBorderGlow, RoundedCornerShape(20.dp))
                    .padding(16.dp)
            ) {
                Column {
                    // Reactions Bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        listOf("👍", "❤️", "🔥", "🎉", "🚀").forEach { emoji ->
                            Text(
                                text = emoji,
                                fontSize = 26.sp,
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .clickable {
                                        AxChetRepository.addReaction(conversationId, msg.id, emoji)
                                        selectedMessageForAction = null
                                    }
                                    .padding(6.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = AxBorderSubtle)

                    // Action buttons
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                clipboardManager.setText(AnnotatedString(msg.text.ifBlank { msg.fileName ?: "" }))
                                Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                                selectedMessageForAction = null
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = null, tint = AxBrightViolet)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Copy Message", color = AxWhite, fontSize = 15.sp)
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                Toast.makeText(context, "Message pinned", Toast.LENGTH_SHORT).show()
                                selectedMessageForAction = null
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.PushPin, contentDescription = null, tint = AxSoftPurple)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Pin to Top", color = AxWhite, fontSize = 15.sp)
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                AxChetRepository.deleteMessage(conversationId, msg.id)
                                selectedMessageForAction = null
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFF87171))
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Delete Message", color = Color(0xFFF87171), fontSize = 15.sp)
                    }
                }
            }
        }
    }

    // Schedule Dialog directly inside chat
    if (showScheduleDialog) {
        Dialog(onDismissRequest = { showScheduleDialog = false }) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF170E2D),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AxBorderGlow, RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                var schedText by remember { mutableStateOf(inputText.ifBlank { "Hey, check this out!" }) }
                var schedDate by remember { mutableStateOf("Tomorrow, 10:00 AM") }

                Column {
                    Text(
                        text = "Schedule Message for ${conv.title}",
                        color = AxWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = schedText,
                        onValueChange = { schedText = it },
                        label = { Text("Message Text") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF100A1F),
                            unfocusedContainerColor = Color(0xFF100A1F),
                            focusedTextColor = AxWhite,
                            unfocusedTextColor = AxWhite
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = schedDate,
                        onValueChange = { schedDate = it },
                        label = { Text("Scheduled Time") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color(0xFF100A1F),
                            unfocusedContainerColor = Color(0xFF100A1F),
                            focusedTextColor = AxWhite,
                            unfocusedTextColor = AxWhite
                        )
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        androidx.compose.material3.TextButton(onClick = { showScheduleDialog = false }) {
                            Text("Cancel", color = AxTextMuted)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        androidx.compose.material3.Button(
                            onClick = {
                                AxChetRepository.scheduleMessage(conv.title, schedText, schedDate, "Scheduled")
                                showScheduleDialog = false
                                Toast.makeText(context, "Message scheduled successfully!", Toast.LENGTH_SHORT).show()
                            },
                            colors = androidx.compose.material3.ButtonDefaults.buttonColors(containerColor = AxBrightViolet)
                        ) {
                            Text("Confirm Schedule", color = AxWhite, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Call Modal Simulation
    showCallDialog?.let { callTitle ->
        Dialog(onDismissRequest = { showCallDialog = null }) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF150C2A),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AxBrightViolet, RoundedCornerShape(24.dp))
                    .padding(24.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    UserAvatar(
                        name = conv.title,
                        avatarRes = conv.avatarRes,
                        size = 72.dp,
                        isGoldAdmin = conv.isGoldAdmin,
                        isBlueVerified = conv.isBlueVerified,
                        ringGlow = true
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(callTitle, color = AxWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Connecting through secure Ax Chet VoIP...", color = AxTextMuted, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(24.dp))
                    IconButton(
                        onClick = { showCallDialog = null },
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFEF4444))
                    ) {
                        Icon(Icons.Default.Call, contentDescription = "End Call", tint = AxWhite)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatHeader(
    title: String,
    avatarRes: Int?,
    isGoldAdmin: Boolean,
    isBlueVerified: Boolean,
    isOnline: Boolean,
    onBack: () -> Unit,
    onTitleClick: () -> Unit,
    onVideoCall: () -> Unit,
    onAudioCall: () -> Unit,
    onMoreClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(62.dp)
            .background(AxDeepBlack)
            .border(
                1.dp,
                Brush.verticalGradient(listOf(Color.Transparent, Color(0xFF211438))),
                RoundedCornerShape(0.dp)
            )
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = AxWhite
            )
        }

        // Avatar + User Info
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .weight(1f)
                .clickable(onClick = onTitleClick)
        ) {
            UserAvatar(
                name = title,
                avatarRes = avatarRes,
                size = 38.dp,
                isGoldAdmin = false, // badge displayed beside name
                isBlueVerified = false,
                ringGlow = true
            )

            Spacer(modifier = Modifier.width(10.dp))

            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = title,
                        color = AxWhite,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    if (isGoldAdmin) {
                        Spacer(modifier = Modifier.width(6.dp))
                        GoldAdminBadge(size = 16.dp)
                    } else if (isBlueVerified) {
                        Spacer(modifier = Modifier.width(6.dp))
                        BlueVerifiedBadge(size = 14.dp)
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isOnline) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(AxOnlineGreen)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Online",
                            color = AxOnlineGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    } else {
                        Text(
                            text = "Offline",
                            color = AxTextDim,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Action Icons: Video, Phone, More
        IconButton(onClick = onVideoCall) {
            Icon(Icons.Default.Videocam, contentDescription = "Video Call", tint = AxWhite)
        }
        IconButton(onClick = onAudioCall) {
            Icon(Icons.Default.Call, contentDescription = "Voice Call", tint = AxWhite)
        }
        IconButton(onClick = onMoreClick) {
            Icon(Icons.Default.MoreVert, contentDescription = "More", tint = AxWhite)
        }
    }
}

@Composable
private fun MessageBubble(
    message: Message,
    onLongClick: () -> Unit,
    onDownloadClick: () -> Unit
) {
    val isOut = message.isOutgoing

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = if (isOut) Arrangement.End else Arrangement.Start
    ) {
        Column(
            horizontalAlignment = if (isOut) Alignment.End else Alignment.Start
        ) {
            // Bubble container
            Box(
                modifier = Modifier
                    .widthIn(min = 60.dp, max = 290.dp)
                    .clip(
                        RoundedCornerShape(
                            topStart = 18.dp,
                            topEnd = 18.dp,
                            bottomStart = if (isOut) 18.dp else 4.dp,
                            bottomEnd = if (isOut) 4.dp else 18.dp
                        )
                    )
                    .background(
                        if (isOut) {
                            Brush.linearGradient(
                                listOf(
                                    AxBubbleOutgoingStart,
                                    AxBubbleOutgoingEnd
                                )
                            )
                        } else {
                            Brush.linearGradient(
                                listOf(
                                    AxBubbleIncoming,
                                    Color(0xFF22163A)
                                )
                            )
                        }
                    )
                    .border(
                        1.dp,
                        if (isOut) AxBrightViolet.copy(alpha = 0.5f) else AxBorderSubtle,
                        RoundedCornerShape(
                            topStart = 18.dp,
                            topEnd = 18.dp,
                            bottomStart = if (isOut) 18.dp else 4.dp,
                            bottomEnd = if (isOut) 4.dp else 18.dp
                        )
                    )
                    .clickable(onClick = onLongClick)
                    .padding(horizontal = 14.dp, vertical = 10.dp)
                    .testTag("msg_bubble_${message.id}")
            ) {
                when (message.type) {
                    MessageType.FILE -> {
                        // File attachment card matching Screenshot 3
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable(onClick = onDownloadClick)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF2A1550))
                                    .border(1.dp, AxBrightViolet, RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Description,
                                    contentDescription = "APK",
                                    tint = AxBrightViolet,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = message.fileName ?: "File",
                                    color = AxWhite,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = message.fileSize ?: "Unknown size",
                                    color = AxTextMuted,
                                    fontSize = 11.sp
                                )
                            }
                            IconButton(
                                onClick = onDownloadClick,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Download,
                                    contentDescription = "Download",
                                    tint = AxWhite,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    MessageType.VOICE -> {
                        // Voice message player card
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(AxBrightViolet),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = AxWhite)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Voice note (${message.audioDurationSeconds}s) 〰〰〰",
                                color = AxWhite,
                                fontSize = 13.sp
                            )
                        }
                    }

                    else -> {
                        Text(
                            text = message.text,
                            color = AxWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Normal,
                            lineHeight = 20.sp
                        )
                    }
                }
            }

            // Timestamp and Delivery Status
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 2.dp, start = 4.dp, end = 4.dp)
            ) {
                Text(
                    text = message.timestamp,
                    color = AxTextDim,
                    fontSize = 10.sp
                )
                if (isOut) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.DoneAll,
                        contentDescription = "Read",
                        tint = AxBrightViolet,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }

            // Reactions chip
            if (message.reactions.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .offset(y = (-6).dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1E1238))
                        .border(1.dp, AxBrightViolet.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    message.reactions.forEach { reaction ->
                        Text(text = reaction, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatInputBar(
    text: String,
    onTextChanged: (String) -> Unit,
    onSendClick: () -> Unit,
    onAttachClick: () -> Unit,
    onCameraClick: () -> Unit,
    onVoiceRecord: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(AxDeepBlack)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Text field container matching Screenshot 3
        Box(
            modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(26.dp))
                .background(Color(0xFF160E28))
                .border(1.dp, Color(0xFF281A45), RoundedCornerShape(26.dp))
                .padding(horizontal = 8.dp, vertical = 2.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = {}, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = Icons.Default.SentimentSatisfiedAlt,
                        contentDescription = "Emoji",
                        tint = AxTextMuted,
                        modifier = Modifier.size(22.dp)
                    )
                }

                OutlinedTextField(
                    value = text,
                    onValueChange = onTextChanged,
                    placeholder = { Text("Type a message...", color = AxTextMuted, fontSize = 14.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_textfield"),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = AxWhite,
                        unfocusedTextColor = AxWhite
                    ),
                    maxLines = 4
                )

                IconButton(onClick = onAttachClick, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = Icons.Default.AttachFile,
                        contentDescription = "Attach",
                        tint = AxTextMuted,
                        modifier = Modifier.size(22.dp)
                    )
                }

                IconButton(onClick = onCameraClick, modifier = Modifier.size(36.dp)) {
                    Icon(
                        imageVector = Icons.Default.PhotoCamera,
                        contentDescription = "Camera",
                        tint = AxTextMuted,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        // Mic or Send Button
        Box(
            modifier = Modifier
                .size(48.dp)
                .shadow(12.dp, CircleShape, spotColor = AxBrightViolet)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        listOf(
                            AxBrightViolet,
                            AxNeonViolet
                        )
                    )
                )
                .clickable(onClick = if (text.isNotBlank()) onSendClick else onVoiceRecord)
                .testTag("btn_send_voice"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (text.isNotBlank()) Icons.AutoMirrored.Filled.Send else Icons.Default.Mic,
                contentDescription = if (text.isNotBlank()) "Send" else "Voice Record",
                tint = AxWhite,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}
