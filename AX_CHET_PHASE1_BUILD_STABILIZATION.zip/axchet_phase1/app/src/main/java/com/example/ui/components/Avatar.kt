package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Story
import com.example.ui.theme.AxBrightViolet
import com.example.ui.theme.AxDeepBlack
import com.example.ui.theme.AxNeonViolet
import com.example.ui.theme.AxSoftPurple
import com.example.ui.theme.AxTextMuted
import com.example.ui.theme.AxWhite

@Composable
fun UserAvatar(
    name: String,
    avatarRes: Int? = null,
    size: Dp = 52.dp,
    isGoldAdmin: Boolean = false,
    isBlueVerified: Boolean = false,
    isOnline: Boolean = false,
    isGroup: Boolean = false,
    isAiAssistant: Boolean = false,
    ringGlow: Boolean = false,
    modifier: Modifier = Modifier
) {
    val ringBrush = Brush.sweepGradient(
        listOf(
            AxNeonViolet,
            AxBrightViolet,
            AxSoftPurple,
            AxNeonViolet
        )
    )

    Box(
        modifier = modifier.size(size + (if (ringGlow) 8.dp else 0.dp)),
        contentAlignment = Alignment.Center
    ) {
        // Glowing ring if requested (e.g. Profile header or Story)
        if (ringGlow) {
            Box(
                modifier = Modifier
                    .size(size + 8.dp)
                    .clip(CircleShape)
                    .border(2.5.dp, ringBrush, CircleShape)
                    .shadow(12.dp, CircleShape, spotColor = AxBrightViolet)
            )
        }

        // Avatar Image or Fallback container
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .background(
                    if (isAiAssistant) Brush.linearGradient(listOf(Color(0xFF2E1065), Color(0xFF581C87)))
                    else if (isGroup) Brush.linearGradient(listOf(Color(0xFF1E1B4B), Color(0xFF312E81)))
                    else Brush.linearGradient(listOf(Color(0xFF261947), Color(0xFF140D26)))
                ),
            contentAlignment = Alignment.Center
        ) {
            if (avatarRes != null) {
                Image(
                    painter = painterResource(id = avatarRes),
                    contentDescription = name,
                    modifier = Modifier
                        .size(size)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
            } else if (isAiAssistant) {
                Icon(
                    imageVector = Icons.Default.SmartToy,
                    contentDescription = "AI Assistant",
                    tint = AxBrightViolet,
                    modifier = Modifier.size(size * 0.55f)
                )
            } else if (isGroup) {
                Icon(
                    imageVector = Icons.Default.Groups,
                    contentDescription = "Group",
                    tint = AxSoftPurple,
                    modifier = Modifier.size(size * 0.55f)
                )
            } else {
                Text(
                    text = name.take(2).uppercase(),
                    color = AxWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = (size.value * 0.38f).sp
                )
            }
        }

        // Badge placement in bottom-right corner
        if (isGoldAdmin) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = 2.dp, y = 2.dp)
            ) {
                GoldAdminBadge(size = (size.value * 0.38f).dp.coerceIn(16.dp, 24.dp))
            }
        } else if (isBlueVerified) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = 2.dp, y = 2.dp)
            ) {
                BlueVerifiedBadge(size = (size.value * 0.35f).dp.coerceIn(14.dp, 22.dp))
            }
        } else if (isOnline) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = 1.dp, y = 1.dp)
            ) {
                OnlineStatusIndicator(size = (size.value * 0.25f).dp.coerceIn(10.dp, 16.dp))
            }
        }
    }
}

/**
 * Story circle item for the horizontal story bar
 */
@Composable
fun StoryItemView(
    story: Story,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .width(68.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        UserAvatar(
            name = story.userName,
            avatarRes = story.userAvatarRes,
            size = 56.dp,
            isGoldAdmin = story.isGoldAdmin,
            isBlueVerified = story.isBlueVerified,
            isOnline = story.isOnline,
            ringGlow = true
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = story.userName,
            color = AxWhite,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

/**
 * "My Story" item with plus badge
 */
@Composable
fun AddStoryItemView(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .width(68.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier.size(64.dp),
            contentAlignment = Alignment.Center
        ) {
            // Dashed border or subtle ring
            Box(
                modifier = Modifier
                    .size(62.dp)
                    .clip(CircleShape)
                    .border(2.dp, Brush.linearGradient(listOf(AxBrightViolet, AxNeonViolet)), CircleShape)
                    .background(Color(0xFF140D26)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "My Story",
                    tint = AxBrightViolet,
                    modifier = Modifier.size(28.dp)
                )
            }

            // Bottom plus badge
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = (-2).dp, y = (-2).dp)
                    .size(20.dp)
                    .clip(CircleShape)
                    .background(AxBrightViolet)
                    .border(2.dp, AxDeepBlack, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    tint = AxWhite,
                    modifier = Modifier.size(12.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "My Story",
            color = AxTextMuted,
            fontSize = 12.sp,
            fontWeight = FontWeight.Normal,
            maxLines = 1,
            textAlign = TextAlign.Center
        )
    }
}
