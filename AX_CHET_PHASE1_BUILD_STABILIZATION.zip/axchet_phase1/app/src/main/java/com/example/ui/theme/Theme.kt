package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = AxBrightViolet,
    onPrimary = AxWhite,
    primaryContainer = AxNeonViolet,
    onPrimaryContainer = AxWhite,
    secondary = AxSoftPurple,
    onSecondary = AxDeepBlack,
    tertiary = AxGoldAdmin,
    onTertiary = AxDeepBlack,
    background = AxDeepBlack,
    onBackground = AxWhite,
    surface = AxDarkPurpleSurface,
    onSurface = AxWhite,
    surfaceVariant = AxSurfaceVariant,
    onSurfaceVariant = AxTextMuted,
    outline = AxBorderGlow,
    outlineVariant = AxBorderSubtle
)

private val LightColorScheme = lightColorScheme(
    primary = AxNeonViolet,
    onPrimary = AxWhite,
    primaryContainer = AxSoftPurple,
    onPrimaryContainer = AxDeepBlack,
    secondary = AxBrightViolet,
    onSecondary = AxWhite,
    tertiary = AxGoldAdmin,
    background = AxDeepBlack,
    onBackground = AxWhite,
    surface = AxDarkPurpleSurface,
    onSurface = AxWhite
)

@Composable
fun AxChetTheme(
    darkTheme: Boolean = true, // Default to Ax Chet's signature cyber midnight dark theme
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = AxDeepBlack.toArgb()
                window.navigationBarColor = AxDeepBlack.toArgb()
                val insetsController = WindowCompat.getInsetsController(window, view)
                insetsController.isAppearanceLightStatusBars = false
                insetsController.isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
