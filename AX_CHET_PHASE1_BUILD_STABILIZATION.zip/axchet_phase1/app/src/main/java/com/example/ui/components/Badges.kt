package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AxBlueVerified
import com.example.ui.theme.AxGoldAdmin
import com.example.ui.theme.AxGoldAdminGlow
import com.example.ui.theme.AxOnlineGreen
import com.example.ui.theme.AxWhite

/**
 * Gold Admin Badge: The prestigious Gold Shield with letter 'A'
 * Reserved exclusively for authorized Ax Chet administrators!
 */
@Composable
fun GoldAdminBadge(
    modifier: Modifier = Modifier,
    size: Dp = 18.dp
) {
    val goldBrush = Brush.linearGradient(
        colors = listOf(
            Color(0xFFFFE072),
            AxGoldAdmin,
            Color(0xFFE5A800),
            Color(0xFFFFD54F)
        )
    )

    Box(
        modifier = modifier
            .size(size)
            .shadow(4.dp, shape = RoundedCornerShape(percent = 40), spotColor = AxGoldAdminGlow)
            .clip(RoundedCornerShape(percent = 40))
            .background(goldBrush)
            .border(1.dp, Color(0xFFFFF3B0), RoundedCornerShape(percent = 40)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "A",
            color = Color(0xFF3E2300),
            fontWeight = FontWeight.Black,
            fontSize = (size.value * 0.58f).sp,
            lineHeight = (size.value * 0.58f).sp
        )
    }
}

/**
 * Blue Verified Badge: Official checkmark circle for verified public figures & bots
 */
@Composable
fun BlueVerifiedBadge(
    modifier: Modifier = Modifier,
    size: Dp = 16.dp
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(AxBlueVerified),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Default.Check,
            contentDescription = "Verified",
            tint = AxWhite,
            modifier = Modifier.size(size * 0.7f)
        )
    }
}

/**
 * Online Status indicator dot
 */
@Composable
fun OnlineStatusIndicator(
    modifier: Modifier = Modifier,
    size: Dp = 10.dp,
    showBorder: Boolean = true
) {
    Box(
        modifier = modifier
            .size(size)
            .then(
                if (showBorder) Modifier.border(2.dp, Color(0xFF080610), CircleShape)
                else Modifier
            )
            .clip(CircleShape)
            .background(AxOnlineGreen)
    )
}

/**
 * Ax Chet Admin Pill displayed on profiles
 */
@Composable
fun AdminRolePill(
    roleTitle: String = "Ax Chet Admin",
    modifier: Modifier = Modifier
) {
    val pillGradient = Brush.horizontalGradient(
        colors = listOf(
            Color(0xFF5B1AA3),
            Color(0xFF7E22CE),
            Color(0xFF4C1D95)
        )
    )

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(pillGradient)
            .border(1.dp, Color(0xFF9333EA).copy(alpha = 0.6f), RoundedCornerShape(16.dp))
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "👑",
            fontSize = 13.sp
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = roleTitle,
            color = AxWhite,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
