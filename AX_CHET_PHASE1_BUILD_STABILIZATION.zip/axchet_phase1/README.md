# AX CHET — Android project

This is the existing native Android application built with Kotlin and Jetpack Compose.

## Open locally

1. Open this project directory in Android Studio.
2. Use JDK 17 or newer for Gradle (AGP 9.1.1 requires JDK 17).
3. Install Android SDK Platform 36 (including extension level 1, as requested by `compileSdk`) and Android SDK Build-Tools 36.0.0.
4. Keep your local `.env` file at the project root. It must define `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY`.
5. Sync Gradle, run `:app:testDebugUnitTest`, then run `:app:assembleDebug`.

Do not put a Supabase service-role/secret key in the Android app. The publishable key is the only client key expected here. Keep `.env`, keystores, and signing passwords out of Git.

## Build on GitHub Actions

The repository includes `.github/workflows/android-build.yml`. After pushing the project to a GitHub repository, open **Actions → Android build → Run workflow**. It installs JDK 17, Gradle 9.3.1, and the Android SDK packages, runs the unit tests and assembles a debug APK. The APK is uploaded as a workflow artifact.

The workflow uses `.env.example` for compilation. It does not prove live Supabase connectivity; run the app on a connected device and invoke the app's diagnostic flow separately for that check.

## Project identity

- Application ID: `com.aistudio.axchet.qqxpvt`
- Namespace: `com.example`
- Minimum SDK: 24
- Target SDK: 36
- Android Gradle Plugin: 9.1.1
- Gradle: 9.3.1
- Kotlin: 2.2.10

The existing Compose UI and navigation are intentionally retained during build stabilization.
