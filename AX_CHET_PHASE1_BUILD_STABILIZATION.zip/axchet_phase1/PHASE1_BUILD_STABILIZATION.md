# AX CHET — Phase 1 Build Stabilization Report

Date: 2026-11-07

## Scope

Stabilize the existing native Android project for reproducible debug builds without recreating the app or changing its Compose UI, navigation, package ID, Supabase project, or dependency versions.

## Changes applied

1. Kept Android Gradle Plugin 9.1.1, Kotlin 2.2.10, and Gradle distribution 9.3.1. The existing `gradle-wrapper.properties` already points to Gradle 9.3.1.
2. Updated debug signing so the project uses its AI Studio `debug.keystore` when that file is present, while clean checkouts without that ignored file fall back to Android Gradle Plugin's default debug signing.
3. Added a GitHub Actions workflow that installs JDK 17, Gradle 9.3.1, Android SDK packages, creates an ephemeral debug keystore, runs unit tests, assembles the debug APK, and uploads the APK artifact.
4. Replaced stale README instructions referring to `GEMINI_API_KEY` and unconditional removal of the debug signing assignment with instructions for the current Supabase configuration and build setup.
5. Preserved the existing Kotlin/Compose source, app identity, SDK levels, Supabase dependencies, and `.env` handling.

## Compatibility check

Android's official AGP 9.1.1 release notes list Gradle 9.3.1 as the minimum/default Gradle version and JDK 17 as the required JDK. The environment used for this preparation has Java 21, which is newer than the minimum. The official AGP compatibility reference is https://developer.android.com/build/releases/agp-9-1-0-release-notes.

## Verification status

- Source archive extracted and inspected: passed.
- Gradle version alignment: passed by configuration inspection (AGP 9.1.1 / Gradle 9.3.1).
- Debug signing fallback: source change applied; not executed in a Gradle build here.
- Workflow file: created; not executed by GitHub Actions here.
- Unit tests: not run.
- Debug APK: not built.
- Live Supabase request: not tested.

The current execution environment has no Android SDK and no installed Gradle. Outbound DNS/network access is unavailable, so Gradle distribution and SDK packages could not be downloaded. The archive also did not contain the official Gradle Wrapper scripts or JAR. Rather than fabricate a nonfunctional wrapper, the workflow installs the exact Gradle version directly and invokes it for the build.

## Required external verification

1. Push this project to a GitHub repository.
2. Run **Actions → Android build → Run workflow** (or push to `main` / `master`).
3. Confirm both `:app:testDebugUnitTest` and `:app:assembleDebug` pass.
4. Download the `ax-chet-debug-apk` artifact and install it on an Android device.
5. Verify launch and navigation, then run the existing Supabase diagnostic on a network-connected device.

## Exit status

**Phase 1 preparation completed; build verification remains pending.** Phase 2 should not start until the CI build, device launch, and live Supabase connectivity checks pass.
